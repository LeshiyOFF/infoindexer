import { Database } from 'duckdb';
import { clickhouseClient, redisSub, redisPub, redisClient, SyncStartPayload, SyncState } from 'shared';
import fs from 'fs';
import path from 'path';

// Parse descriptive_names_dict.csv
const mapNames = (): Record<string, string> => {
  const content = fs.readFileSync(path.join(__dirname, '../descriptive_names_dict.csv'), 'utf-8');
  const lines = content.trim().split('\n');
  const dict: Record<string, string> = {};
  const seen: Record<string, number> = {};
  for (let i = 1; i < lines.length; i++) {
    const [original, descriptive] = lines[i].split(',');
    if (original && descriptive) {
      let mapped = descriptive.trim();
      if (seen[mapped]) {
        seen[mapped]++;
        mapped = `${mapped}_${seen[mapped]}`;
      } else {
        seen[mapped] = 1;
      }
      dict[original.trim()] = mapped;
    }
  }
  return dict;
};

const columnMap = mapNames();

const getClickHouseType = (duckdbType: string, columnName: string): string => {
  const lcColumns = ['okved2', 'region', 'inn', 'kpp', 'region_taxcode', 'okpo', 'okopf', 'okfs', 'okato', 'oktmo'];
  
  let chType = 'String';
  if (duckdbType.includes('VARCHAR')) chType = 'String';
  else if (duckdbType.includes('BIGINT')) chType = 'Int64';
  else if (duckdbType.includes('INTEGER')) chType = 'Int32';
  else if (duckdbType.includes('DOUBLE')) chType = 'Float64';
  else if (duckdbType.includes('FLOAT')) chType = 'Float32';
  else if (duckdbType.includes('BOOLEAN')) chType = 'UInt8';
  else if (duckdbType.includes('DATE')) chType = 'Date';
  else if (duckdbType.includes('TIMESTAMP')) chType = 'DateTime';

  if (lcColumns.includes(columnName) && chType === 'String') {
    return `LowCardinality(String)`;
  }

  return `Nullable(${chType})`;
};

const getDuckDBConnection = async (): Promise<{ db: Database, conn: any }> => {
  return new Promise((resolve, reject) => {
    const db = new Database(':memory:');
    const extPath = path.join(__dirname, '../httpfs.duckdb_extension');
    console.log(`Installing DuckDB extension from: ${extPath}`);
    db.run(`INSTALL '${extPath}';`, (err) => {
      if (err) {
        console.error('Failed to install DuckDB extension:', err);
        return reject(err);
      }
      console.log('DuckDB extension installed. Loading...');
      db.run(`LOAD '${extPath}';`, (err) => {
        if (err) {
          console.error('Failed to load DuckDB extension:', err);
          return reject(err);
        }
        console.log('DuckDB extension loaded.');
        resolve({ db, conn: db.connect() });
      });
    });
  });
};

const ensureTableExists = async (conn: any, year: number) => {
  return new Promise<void>((resolve, reject) => {
    const url = `https://huggingface.co/datasets/irlspbru/RFSD/resolve/main/RFSD/year=${year}/part-0.parquet`;
    conn.all(`DESCRIBE SELECT * FROM read_parquet('${url}') LIMIT 1`, async (err: any, rows: any[]) => {
      if (err) return reject(err);
      
      const columns = rows.map(r => {
        const originalName = r.column_name;
        const mappedName = columnMap[originalName] || originalName;
        return `\`${mappedName}\` ${getClickHouseType(r.column_type, mappedName)}`;
      });
      
      const query = `
        CREATE TABLE IF NOT EXISTS financial_reports (
          ${columns.join(',\n')}
        ) ENGINE = MergeTree()
        ORDER BY inn
      `;
      
      try {
        await clickhouseClient.command({ query });
        resolve();
      } catch (e) {
        reject(e);
      }
    });
  });
};

const reportProgress = async (year: number, state: SyncState) => {
  if (state.status === 'running' || state.status === 'completed') {
    await redisClient.hdel(`sync:status:${year}`, 'error');
  }
  await redisClient.hset(`sync:status:${year}`, state as any);
};

const abortedYears = new Set<number>();

const runSync = async (year: number) => {
  const url = `https://huggingface.co/datasets/irlspbru/RFSD/resolve/main/RFSD/year=${year}/part-0.parquet`;
  console.log(`--- STARTING GIR BO SYNC FOR ${year} ---`);
  
  await reportProgress(year, { status: 'running', percentage: 0, rows_processed: 0 });
  abortedYears.delete(year);
  
  let db: Database | undefined;
  let conn: any;
  try {
    console.log('Connecting to DuckDB...');
    const connectionResult = await getDuckDBConnection();
    db = connectionResult.db;
    conn = connectionResult.conn;
    console.log('DuckDB connected. Ensuring table exists in ClickHouse...');
    await ensureTableExists(conn, year);
    
    console.log('Getting total rows from Parquet...');
    const totalRows: number = await new Promise((resolve, reject) => {
      conn.all(`SELECT COUNT(*) as total FROM read_parquet('${url}')`, (err: any, res: any[]) => {
        if (err) return reject(err);
        resolve(Number(res[0].total));
      });
    });
    console.log(`Total rows to process: ${totalRows}`);    
    const stream = conn.stream(`SELECT * FROM read_parquet('${url}')`);
    let batch: any[] = [];
    let processed = 0;
    let lastReportPercentage = 0;
    
    const batchSize = parseInt(process.env.BATCH_SIZE || '20000');
    
    for await (const row of stream) {
      if (abortedYears.has(year)) {
        throw new Error('Sync aborted by user');
      }

      const mappedRow: Record<string, any> = {};
      for (const [key, val] of Object.entries(row as Record<string, any>)) {
        let finalVal = val;
        if (typeof val === 'bigint') {
          finalVal = val.toString();
        } else if (val instanceof Date || Object.prototype.toString.call(val) === '[object Date]') {
          if ((val as Date).getUTCHours() === 0 && (val as Date).getUTCMinutes() === 0 && (val as Date).getUTCSeconds() === 0 && (val as Date).getUTCMilliseconds() === 0) {
            finalVal = (val as Date).toISOString().split('T')[0];
          } else {
            finalVal = (val as Date).toISOString().replace('T', ' ').substring(0, 19);
          }
        }
        mappedRow[columnMap[key] || key] = finalVal;
      }
      batch.push(mappedRow);
      processed++;
      
      if (batch.length >= batchSize) {
        await clickhouseClient.insert({
          table: 'financial_reports',
          values: batch,
          format: 'JSONEachRow'
        });
        batch = [];
        
        const percentage = Math.floor((processed / totalRows) * 100);
        if (percentage >= lastReportPercentage + 5) {
          lastReportPercentage = percentage;
          await reportProgress(year, { status: 'running', percentage, rows_processed: processed });
        }
      }
    }
    
    if (batch.length > 0) {
      await clickhouseClient.insert({
        table: 'financial_reports',
        values: batch,
        format: 'JSONEachRow'
      });
    }
    
    await reportProgress(year, { status: 'completed', percentage: 100, rows_processed: processed, completed_at: new Date().toISOString() });
    console.log(`Sync for ${year} completed.`);
    
  } catch (error: any) {
    if (error.message === 'Sync aborted by user') {
      console.log(`Sync for ${year} aborted.`);
      await reportProgress(year, { status: 'idle', percentage: 0, rows_processed: 0 });
    } else {
      console.error(`Sync error for ${year}:`, error);
      await reportProgress(year, { status: 'error', percentage: 0, rows_processed: 0, error: error.message });
    }
  } finally {
    abortedYears.delete(year);
    if (conn) await conn.close();
    // DuckDB Database close is synchronous or might not be available in some versions, but we should try
    if (db && typeof (db as { close?: () => void }).close === 'function') {
      try {
        (db as { close: () => void }).close();
      } catch {
        // игнорируем ошибки закрытия
      }
    }
  }
};

redisSub.subscribe('sync:start', 'sync:abort', (err, count) => {
  if (err) {
    console.error('Failed to subscribe: %s', err.message);
  } else {
    console.log(`Subscribed successfully! Listening for sync:start, sync:abort`);
  }
});

redisSub.on('message', async (channel, message) => {
  if (channel === 'sync:start') {
    const payload: SyncStartPayload = JSON.parse(message);
    console.log(`Received start command for year: ${payload.year}`);
    
    // Fire and forget
    runSync(payload.year).catch(console.error);
  } else if (channel === 'sync:abort') {
    const payload: { year: number } = JSON.parse(message);
    console.log(`Received abort command for year: ${payload.year}`);
    abortedYears.add(payload.year);
  }
});
