import { clickhouseClient, redisClient, redisSub } from 'shared';
import readline from 'readline';
import { SocksProxyAgent } from 'socks-proxy-agent';
import axios, { type AxiosResponse } from 'axios';

const proxyUrl = process.env.SOCKS_PROXY_URL;
/** socks5h = remote DNS на стороне прокси, обходит локальную блокировку доменов */
const proxyUrlWithRemoteDns = proxyUrl?.replace(/^socks5:\/\//, 'socks5h://');
const proxyAgent = proxyUrlWithRemoteDns ? new SocksProxyAgent(proxyUrlWithRemoteDns) : null;

const PROXY_RETRIES = 6;
const RETRY_DELAY_MS = 3000;

const isRetryableError = (e: unknown): boolean => {
  const err = e as { code?: string; message?: string; cause?: { code?: string } };
  if (err?.code === 'ECONNREFUSED' && err?.message?.includes('127.0.0.1')) return false;
  return err?.code === 'ECONNRESET'
    || err?.cause?.code === 'ECONNRESET'
    || (typeof err?.message === 'string' && err.message.includes('TLS'));
};

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

interface FTMEntity {
  id: string;
  schema: string;
  properties: {
    innCode?: string[];
    name?: string[];
    status?: string[];
    address?: string[];
    director?: string[];
    organization?: string[];
    incorporationDate?: string[];
    role?: string[];
  };
}

interface EgrulProgressState {
  status: string;
  percentage?: number;
  message?: string;
  error?: string;
  updated_at?: string;
  completed_at?: string;
}

interface EgrulCompanyRow {
  id: string;
  inn: string;
  name: string;
  status: string;
  address: string;
}

interface EgrulPersonRow {
  id: string;
  name: string;
}

interface EgrulDirectorshipRow {
  organization_id: string;
  director_id: string;
}

const ensureTables = async () => {
  await clickhouseClient.command({
    query: `
      CREATE TABLE IF NOT EXISTS companies_meta (
        inn String,
        name String,
        director String,
        status String,
        address String,
        founders Array(String),
        updated_at DateTime DEFAULT now(),
        INDEX name_idx name TYPE tokenbf_v1(4096, 3, 0) GRANULARITY 1,
        INDEX director_idx director TYPE tokenbf_v1(4096, 3, 0) GRANULARITY 1,
        INDEX status_idx status TYPE set(10) GRANULARITY 1
      ) ENGINE = ReplacingMergeTree(updated_at)
      ORDER BY inn
    `
  });

  // Ensure no employees column if it existed previously
  try {
    await clickhouseClient.command({ query: `ALTER TABLE companies_meta DROP COLUMN IF EXISTS employees` });
  } catch (e) { /* ignore */ }
  
  // Apply indexes if table already existed without them
  try {
    await clickhouseClient.command({ query: `ALTER TABLE companies_meta ADD INDEX IF NOT EXISTS name_idx name TYPE tokenbf_v1(4096, 3, 0) GRANULARITY 1` });
    await clickhouseClient.command({ query: `ALTER TABLE companies_meta ADD INDEX IF NOT EXISTS director_idx director TYPE tokenbf_v1(4096, 3, 0) GRANULARITY 1` });
    await clickhouseClient.command({ query: `ALTER TABLE companies_meta ADD INDEX IF NOT EXISTS status_idx status TYPE set(10) GRANULARITY 1` });
  } catch (e) { /* ignore */ }

  await clickhouseClient.command({ query: `DROP TABLE IF EXISTS egrul_companies_raw` });
  await clickhouseClient.command({ query: `DROP TABLE IF EXISTS egrul_persons_raw` });
  await clickhouseClient.command({ query: `DROP TABLE IF EXISTS egrul_directorships_raw` });

  await clickhouseClient.command({
    query: `CREATE TABLE egrul_companies_raw (id String, inn String, name String, status String, address String) ENGINE = MergeTree() ORDER BY id`
  });
  await clickhouseClient.command({
    query: `CREATE TABLE egrul_persons_raw (id String, name String) ENGINE = MergeTree() ORDER BY id`
  });
  await clickhouseClient.command({
    query: `CREATE TABLE egrul_directorships_raw (organization_id String, director_id String) ENGINE = MergeTree() ORDER BY organization_id`
  });
};

const reportProgress = async (state: EgrulProgressState) => {
  const record: Record<string, string> = {};
  Object.entries(state).forEach(([k, v]) => {
    record[k] = v !== undefined ? String(v) : '';
  });
  await redisClient.hset('sync:status:egrul', record);
};

const axiosFetch = (url: string, useProxy: boolean) =>
  axios.get(url, {
    httpsAgent: useProxy && proxyAgent ? proxyAgent : undefined,
    headers: { 'User-Agent': 'Mozilla/5.0 (compatible; InfoIndexer/1.0; +https://github.com/)' }
  });

const fetchDownloadUrl = async (): Promise<string> => {
  const url = 'https://www.opensanctions.org/datasets/ru_egrul/';
  const useProxy = !!proxyAgent;
  let lastError: unknown;
  for (let i = 0; i < (useProxy ? PROXY_RETRIES : 1); i++) {
    try {
      if (i > 0) {
        await sleep(RETRY_DELAY_MS * i);
        console.log(`Retry ${i}/${PROXY_RETRIES} via proxy...`);
      }
      const response = await axiosFetch(url, useProxy);
      const match = response.data.match(/href=['"]([^'"]*\/ru_egrul\/entities\.ftm\.json)['"]/);
      if (match) {
        let link = match[1];
        if (link.startsWith('/')) link = 'https://data.opensanctions.org' + link;
        return link;
      }
      throw new Error('Could not find FTM JSON download link on OpenSanctions page.');
    } catch (e) {
      lastError = e;
      if (!isRetryableError(e) || i === (useProxy ? PROXY_RETRIES : 1) - 1) break;
    }
  }
  throw new Error(`Failed to fetch download URL: ${lastError}`);
};

const insertBatch = async (
  table: string,
  values: EgrulCompanyRow[] | EgrulPersonRow[] | EgrulDirectorshipRow[]
): Promise<void> => {
  if (values.length === 0) return;
  await clickhouseClient.insert({
    table,
    values: values as unknown as Record<string, unknown>[],
    format: 'JSONEachRow'
  });
};

const runEgrulSync = async () => {
  let processedRecords = 0;
  let companiesBatch: EgrulCompanyRow[] = [];
  let personsBatch: EgrulPersonRow[] = [];
  let directorshipsBatch: EgrulDirectorshipRow[] = [];

  try {
    console.log('--- STARTING EGRUL SYNC (OpenSanctions FTM) ---');
    console.log(proxyUrl ? `Using SOCKS5 proxy: ${proxyUrl}` : 'Connecting directly (no proxy)');
    
    await reportProgress({ 
      status: 'running', 
      percentage: 0, 
      message: 'Инициализация синхронизации: поиск ссылки на дамп...',
      updated_at: new Date().toISOString()
    });
    
    console.log('Checking ClickHouse tables...');
    await ensureTables();

    const dumpUrl = await fetchDownloadUrl();
    console.log(`Found FTM download URL: ${dumpUrl}`);

    await reportProgress({ 
      status: 'running', 
      percentage: 1, 
      message: 'Загрузка данных OpenSanctions началась...',
      updated_at: new Date().toISOString()
    });

    const batchSize = parseInt(process.env.BATCH_SIZE || '100000');

    const streamOpts = (useProxy: boolean) => ({
      responseType: 'stream' as const,
      httpsAgent: useProxy && proxyAgent ? proxyAgent : undefined,
      timeout: 0,
      maxRedirects: 10,
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; InfoIndexer/1.0; +https://github.com/)' }
    });

    const useProxy = !!proxyAgent;
    const maxAttempts = useProxy ? PROXY_RETRIES : 1;
    let response: AxiosResponse | undefined;
    for (let i = 0; i < maxAttempts; i++) {
      try {
        if (i > 0) {
          await sleep(RETRY_DELAY_MS * i);
          console.log(`Retry stream ${i}/${maxAttempts}...`);
        }
        response = await axios.get(dumpUrl, streamOpts(useProxy));
        break;
      } catch (e) {
        if (!isRetryableError(e) || i === maxAttempts - 1) {
          const hint = (e as Error)?.message?.includes('127.0.0.1')
            ? ' Домен заблокирован. Требуется рабочий SOCKS_PROXY_URL.'
            : '';
          throw new Error(`Failed to download dump: ${e}${hint}`);
        }
      }
    }
    if (response === undefined) throw new Error('Failed to download dump');

    if (response.status !== 200) {
      throw new Error(`Failed to download dump: HTTP ${response.status}`);
    }

    const rl = readline.createInterface({
      input: response.data,
      crlfDelay: Infinity
    });

    let totalLinesScanned = 0;

    for await (const line of rl) {
      if (!line.trim()) continue;
      totalLinesScanned++;

      if (totalLinesScanned % 100000 === 0) {
        console.log(`[Stream Tracker] Scanned ${totalLinesScanned.toLocaleString()} lines...`);
        if (totalLinesScanned % 500000 === 0) {
          reportProgress({ 
            status: 'running', 
            percentage: 1,
            message: `Чтение потока: ${totalLinesScanned.toLocaleString()} строк...`,
            updated_at: new Date().toISOString()
          }).catch(console.error);
        }
      }

      try {
        const entity: FTMEntity = JSON.parse(line);
        
        if (entity.schema === 'Company' || entity.schema === 'Organization' || entity.schema === 'LegalEntity') {
          const inn = entity.properties.innCode?.[0] || '';
          if (inn) {
            companiesBatch.push({
              id: entity.id,
              inn,
              name: entity.properties.name?.[0] || '',
              status: entity.properties.status?.[0] || 'Действующая',
              address: entity.properties.address?.[0] || ''
            });
            processedRecords++;
          }
        } else if (entity.schema === 'Person') {
          const name = entity.properties.name?.[0] || '';
          if (name) {
            personsBatch.push({
              id: entity.id,
              name
            });
          }
        } else if (entity.schema === 'Directorship') {
          const orgId = entity.properties.organization?.[0] || '';
          const dirId = entity.properties.director?.[0] || '';
          if (orgId && dirId) {
            directorshipsBatch.push({
              organization_id: orgId,
              director_id: dirId
            });
          }
        }

        if (companiesBatch.length >= batchSize) {
          await insertBatch('egrul_companies_raw', companiesBatch);
          companiesBatch = [];
        }
        if (personsBatch.length >= batchSize) {
          await insertBatch('egrul_persons_raw', personsBatch);
          personsBatch = [];
        }
        if (directorshipsBatch.length >= batchSize) {
          await insertBatch('egrul_directorships_raw', directorshipsBatch);
          directorshipsBatch = [];
        }
      } catch (e) {
        console.error('Error parsing line:', e);
      }
    }

    await insertBatch('egrul_companies_raw', companiesBatch);
    await insertBatch('egrul_persons_raw', personsBatch);
    await insertBatch('egrul_directorships_raw', directorshipsBatch);

    console.log('Stream completed. Merging relations in ClickHouse...');
    await reportProgress({ 
      status: 'running', 
      percentage: 50, 
      message: `Слияние данных директоров...`,
      updated_at: new Date().toISOString()
    });

    await clickhouseClient.command({
      query: `
        INSERT INTO companies_meta (inn, name, status, address, director, founders, updated_at)
        SELECT 
          c.inn,
          any(c.name) as name,
          any(c.status) as status,
          any(c.address) as address,
          any(p.name) as director,
          [] as founders,
          now() as updated_at
        FROM egrul_companies_raw c
        LEFT JOIN egrul_directorships_raw d ON c.id = d.organization_id
        LEFT JOIN egrul_persons_raw p ON d.director_id = p.id
        GROUP BY c.inn
      `
    });

    console.log('Cleaning up temporary tables...');
    await clickhouseClient.command({ query: `DROP TABLE IF EXISTS egrul_companies_raw` });
    await clickhouseClient.command({ query: `DROP TABLE IF EXISTS egrul_persons_raw` });
    await clickhouseClient.command({ query: `DROP TABLE IF EXISTS egrul_directorships_raw` });

    console.log('EGRUL (OpenSanctions) sync completed!');
    await reportProgress({ 
      status: 'completed', 
      percentage: 100, 
      message: `Успешно: загружено ${processedRecords.toLocaleString()} компаний`,
      completed_at: new Date().toISOString()
    });

  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : String(error);
    console.error('CRITICAL EGRUL SYNC ERROR:', error);
    await reportProgress({
      status: 'error',
      error: msg,
      message: `Ошибка: ${msg}`,
      updated_at: new Date().toISOString()
    });
  }
};

redisSub.subscribe('sync:egrul:start', (err: Error | null | undefined) => {
  if (err) {
    console.error('Failed to subscribe to sync:egrul:start:', err);
  } else {
    console.log('EGRUL Sync Worker: Successfully subscribed to channel "sync:egrul:start"');
  }
});

redisSub.on('message', (channel: string, message: string) => {
  console.log(`Worker received message on channel [${channel}]`);
  if (channel === 'sync:egrul:start') {
    console.log('Command recognized. Triggering runEgrulSync()...');
    runEgrulSync().catch(err => {
        console.error('Unhandled runEgrulSync error:', err);
    });
  }
});
