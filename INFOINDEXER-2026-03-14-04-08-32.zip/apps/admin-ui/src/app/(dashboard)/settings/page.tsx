"use client";

import { useEffect, useState, useCallback } from 'react';
import { getAuthHeaders } from '@/lib/api';
import { DataManagementCard } from './components/DataManagementCard';
import { StatsCard } from './components/StatsCard';
import { ManageDatasetsModal } from './components/ManageDatasetsModal';
import { EgrulManageModal } from './components/EgrulManageModal';
import { DownloadDatasetsModal } from './components/DownloadDatasetsModal';

export interface YearStatus {
  status: string;
  percentage: number;
  rows_processed?: number;
  error?: string;
  completed_at?: string;
}

export interface EgrulStatus {
  status: string;
  percentage?: number;
  message?: string;
  error?: string;
  rows_processed?: number;
  completed_at?: string;
}

export interface RefreshSummaryStatus {
  status: string;
  percentage?: number;
  message?: string;
  error?: string;
  rows?: number;
  elapsedMs?: number;
  completed_at?: string;
}

export interface Stats {
  totalRecords: number;
  companiesGirBo: number;
  companiesEgrul: number;
  redisMemory: string;
}

const YEARS = Array.from({ length: 14 }, (_, i) => 2011 + i);

export default function SettingsPage() {
  const [stats, setStats] = useState<Stats>({
    totalRecords: 0,
    companiesGirBo: 0,
    companiesEgrul: 0,
    redisMemory: '0B'
  });
  const [statuses, setStatuses] = useState<Record<string, YearStatus | EgrulStatus | RefreshSummaryStatus>>({});
  const [downloadModalOpen, setDownloadModalOpen] = useState(false);
  const [manageModalOpen, setManageModalOpen] = useState(false);
  const [egrulManageModalOpen, setEgrulManageModalOpen] = useState(false);
  const [selectedYears, setSelectedYears] = useState<Set<number>>(new Set());
  const [selectedYearsToDelete, setSelectedYearsToDelete] = useState<Set<number>>(new Set());
  const [downloadInProgress, setDownloadInProgress] = useState(false);
  const [deleteInProgress, setDeleteInProgress] = useState(false);

  const fetchStats = useCallback(async () => {
    try {
      const res = await fetch('/api/stats', { headers: getAuthHeaders() });
      const data = await res.json();
      if (!data.error) {
        setStats({
          totalRecords: data.totalRecords ?? 0,
          companiesGirBo: data.companiesGirBo ?? 0,
          companiesEgrul: data.companiesEgrul ?? 0,
          redisMemory: data.redisMemory ?? '0B'
        });
      }
    } catch (e) {
      console.warn('Settings: fetchStats error', e);
    }
  }, []);

  const fetchStatuses = useCallback(async () => {
    try {
      const res = await fetch('/api/sync/status', { headers: getAuthHeaders() });
      const data = await res.json();
      if (!data.error) setStatuses(data);
    } catch (e) {
      console.warn('Settings: fetchStatuses error', e);
    }
  }, []);

  useEffect(() => {
    fetchStats();
    fetchStatuses();
    const interval = setInterval(() => {
      fetchStats();
      fetchStatuses();
    }, 3000);
    return () => clearInterval(interval);
  }, [fetchStats, fetchStatuses]);

  const handleResponse = async (res: Response): Promise<boolean> => {
    if (res.status === 401) {
      alert('Ошибка авторизации. Проверьте пароль.');
      return false;
    }
    return true;
  };

  const startEgrulSync = async () => {
    const res = await fetch('/api/sync/egrul/start', { method: 'POST', headers: getAuthHeaders() });
    if (await handleResponse(res)) fetchStatuses();
  };

  const notDownloadedYears = YEARS.filter((y) => (statuses[y] as YearStatus)?.status !== 'completed');
  const yearsForDeletion = YEARS.filter(
    (y) => (statuses[y] as YearStatus)?.status === 'completed' || (statuses[y] as YearStatus)?.status === 'running'
  );

  const summaryStatus = statuses['refresh_summary'] as RefreshSummaryStatus | undefined;
  const egrulStatus = (statuses['egrul'] as EgrulStatus) ?? { status: 'idle' };
  const anySyncRunning =
    egrulStatus.status === 'running' ||
    (summaryStatus?.status === 'running') ||
    YEARS.some((y) => (statuses[y] as YearStatus)?.status === 'running');

  const formatLastSync = (iso?: string): string | null => {
    if (!iso) return null;
    try {
      return new Date(iso).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    } catch {
      return null;
    }
  };

  const yearStatuses = Object.fromEntries(YEARS.map((y) => [y, (statuses[y] as YearStatus) ?? { status: 'idle', percentage: 0 }])) as Record<number, YearStatus>;

  const refreshSummary = async () => {
    if (anySyncRunning) return;
    try {
      const res = await fetch('/api/refresh-summary', { method: 'POST', headers: getAuthHeaders() });
      if (res.status === 401) {
        alert('Ошибка авторизации. Проверьте пароль.');
        return;
      }
      await res.json();
      if (res.status === 400) fetchStatuses();
      else if (res.ok) fetchStatuses();
    } catch {
      fetchStatuses();
    }
  };

  const toggleYear = (year: number) => {
    setSelectedYears((prev) => {
      const next = new Set(prev);
      if (next.has(year)) next.delete(year);
      else next.add(year);
      return next;
    });
  };
  const toggleYearToDelete = (year: number) => {
    setSelectedYearsToDelete((prev) => {
      const next = new Set(prev);
      if (next.has(year)) next.delete(year);
      else next.add(year);
      return next;
    });
  };
  const selectAll = () => setSelectedYears(new Set(notDownloadedYears));
  const clearSelection = () => setSelectedYears(new Set());

  const startDownloadSelected = async () => {
    if (selectedYears.size === 0) return;
    setDownloadInProgress(true);
    const years = Array.from(selectedYears).sort((a, b) => a - b);
    for (const year of years) {
      const res = await fetch('/api/sync/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ year })
      });
      if (!(await handleResponse(res))) break;
    }
    setDownloadInProgress(false);
    setDownloadModalOpen(false);
    setSelectedYears(new Set());
    fetchStatuses();
    fetchStats();
  };

  const deleteSelectedYears = async () => {
    if (selectedYearsToDelete.size === 0) return;
    if (!confirm(`Удалить данные за ${Array.from(selectedYearsToDelete).sort((a, b) => a - b).join(', ')}?`)) return;
    setDeleteInProgress(true);
    const years = Array.from(selectedYearsToDelete).sort((a, b) => a - b);
    for (const year of years) {
      const res = await fetch('/api/sync/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ year })
      });
      if (!(await handleResponse(res))) break;
    }
    setDeleteInProgress(false);
    setManageModalOpen(false);
    setSelectedYearsToDelete(new Set());
    fetchStatuses();
    fetchStats();
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-black text-gray-900 uppercase tracking-tight">Параметры системы</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        <DataManagementCard
          yearStatuses={yearStatuses}
          egrulStatus={egrulStatus}
          summaryStatus={summaryStatus}
          anySyncRunning={anySyncRunning}
          formatLastSync={formatLastSync}
          onDownloadClick={() => {
            setSelectedYears(new Set());
            setDownloadModalOpen(true);
          }}
          onManageClick={() => {
            setSelectedYearsToDelete(new Set());
            setManageModalOpen(true);
          }}
          onEgrulSync={startEgrulSync}
          onEgrulManageClick={() => setEgrulManageModalOpen(true)}
          onRefreshSummary={refreshSummary}
        />
        <StatsCard stats={stats} />
      </div>

      <ManageDatasetsModal
        open={manageModalOpen}
        onClose={() => !deleteInProgress && setManageModalOpen(false)}
        yearsForDeletion={yearsForDeletion}
        selectedYearsToDelete={selectedYearsToDelete}
        onToggleYear={toggleYearToDelete}
        deleteInProgress={deleteInProgress}
        onDelete={deleteSelectedYears}
      />

      <EgrulManageModal
        open={egrulManageModalOpen}
        onClose={() => setEgrulManageModalOpen(false)}
        egrulStatus={egrulStatus}
        onSync={startEgrulSync}
        onFetch={() => {
          fetchStats();
          fetchStatuses();
        }}
      />

      <DownloadDatasetsModal
        open={downloadModalOpen}
        onClose={() => !downloadInProgress && setDownloadModalOpen(false)}
        notDownloadedYears={notDownloadedYears}
        selectedYears={selectedYears}
        onToggleYear={toggleYear}
        onSelectAll={selectAll}
        onClearSelection={clearSelection}
        downloadInProgress={downloadInProgress}
        onDownload={startDownloadSelected}
      />
    </div>
  );
}
