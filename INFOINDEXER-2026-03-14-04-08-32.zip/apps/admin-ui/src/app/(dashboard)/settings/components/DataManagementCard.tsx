"use client";

import { Download, RefreshCw, Settings2, Zap } from 'lucide-react';

interface YearStatus {
  status: string;
  percentage: number;
  rows_processed?: number;
  error?: string;
}

interface EgrulStatus {
  status: string;
  percentage?: number;
  message?: string;
  rows_processed?: number;
  completed_at?: string;
}

interface RefreshSummaryStatus {
  status: string;
  percentage?: number;
  message?: string;
  error?: string;
  rows?: number;
  elapsedMs?: number;
  completed_at?: string;
}

export interface DataManagementCardProps {
  yearStatuses: Record<number, YearStatus>;
  egrulStatus: EgrulStatus;
  summaryStatus: RefreshSummaryStatus | undefined;
  anySyncRunning: boolean;
  formatLastSync: (iso?: string) => string | null;
  onDownloadClick: () => void;
  onManageClick: () => void;
  onEgrulSync: () => void;
  onEgrulManageClick: () => void;
  onRefreshSummary: () => void;
}

const YEARS = Array.from({ length: 14 }, (_, i) => 2011 + i);

export function DataManagementCard({
  yearStatuses,
  egrulStatus,
  summaryStatus,
  anySyncRunning,
  formatLastSync,
  onDownloadClick,
  onManageClick,
  onEgrulSync,
  onEgrulManageClick,
  onRefreshSummary
}: DataManagementCardProps) {
  return (
    <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6">
      <h2 className="text-lg font-black text-gray-900 uppercase tracking-wider mb-6">Управление данными</h2>
      <div className="space-y-6">
        <div>
          <p className="text-xs font-bold text-gray-600 uppercase tracking-wider mb-2">Финансовая отчётность (ГИР БО)</p>
          <p className="text-xs text-gray-500 mb-2">Данные финансовой отчётности.</p>
          <div className="flex gap-2">
            <button
              onClick={onDownloadClick}
              className="flex items-center gap-2 px-4 py-2.5 bg-black text-white rounded-xl text-sm font-bold hover:bg-gray-800 transition-colors"
            >
              <Download className="w-4 h-4" /> Скачать набор
            </button>
            <button
              onClick={onManageClick}
              className="flex items-center gap-2 px-4 py-2.5 border-2 border-gray-300 text-gray-700 rounded-xl text-sm font-bold hover:bg-gray-100 transition-colors"
            >
              <Settings2 className="w-4 h-4" /> Управление наборами
            </button>
          </div>
          <div className="mt-2 space-y-1">
            {YEARS.map((year) => {
              const ys = yearStatuses[year];
              if (!ys || ys.status === 'idle' || ys.status === 'completed') return null;
              return (
                <div key={year} className="text-xs text-gray-600 flex items-center gap-2">
                  <span className="font-bold">{year}:</span>
                  {ys.status === 'running' ? (
                    <>
                      <span>{(ys.rows_processed ?? 0).toLocaleString('ru-RU')} строк</span>
                      <span>·</span>
                      <span>{ys.percentage ?? 0}%</span>
                    </>
                  ) : ys.status === 'error' ? (
                    <span className="text-red-600">{ys.error ?? 'Ошибка'}</span>
                  ) : null}
                </div>
              );
            })}
          </div>
        </div>
        <div>
          <p className="text-xs font-bold text-gray-600 uppercase tracking-wider mb-2">Реестр Юрлиц (ЕГРЮЛ / МСП)</p>
          <p className="text-xs text-gray-500 mb-2">Данные названий, адресов и даты регистрации.</p>
          <div className="flex gap-2">
            <button
              onClick={onEgrulSync}
              disabled={egrulStatus.status === 'running'}
              className="flex items-center gap-2 px-4 py-2.5 bg-black text-white rounded-xl text-sm font-bold hover:bg-gray-800 disabled:opacity-50 transition-colors"
            >
              {egrulStatus.status === 'running' ? <RefreshCw className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
              Обновить
            </button>
            <button
              onClick={onEgrulManageClick}
              className="flex items-center gap-2 px-4 py-2.5 border-2 border-gray-300 text-gray-700 rounded-xl text-sm font-bold hover:bg-gray-100 transition-colors"
            >
              <Settings2 className="w-4 h-4" /> Управление
            </button>
          </div>
          {egrulStatus.status === 'running' && (
            <div className="mt-2 space-y-1">
              <p className="text-xs text-gray-600">
                {egrulStatus.rows_processed != null && <>{egrulStatus.rows_processed.toLocaleString('ru-RU')} строк</>}
                {egrulStatus.rows_processed != null && egrulStatus.percentage != null && ' · '}
                {egrulStatus.percentage != null && <>{egrulStatus.percentage}%</>}
                {egrulStatus.message && <> · {egrulStatus.message}</>}
              </p>
            </div>
          )}
          {egrulStatus.completed_at && egrulStatus.status !== 'running' && (
            <p className="text-xs text-gray-500 mt-1">
              Последняя синхронизация: {formatLastSync(egrulStatus.completed_at) ?? '—'}
            </p>
          )}
        </div>
        <div>
          <p className="text-xs font-bold text-gray-600 uppercase tracking-wider mb-2">Кэш для поиска</p>
          <p className="text-xs text-gray-500 mb-2">Кэш нужно обновлять после загрузки данных для более быстрого поиска.</p>
          <button
            onClick={onRefreshSummary}
            disabled={anySyncRunning}
            className="flex items-center gap-2 px-4 py-2.5 bg-black text-white rounded-xl text-sm font-bold hover:bg-gray-800 disabled:opacity-50 transition-colors"
          >
            {summaryStatus?.status === 'running' ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
            Обновить кэш
          </button>
          {summaryStatus?.status === 'running' && (
            <div className="mt-2 space-y-1">
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-black/80 rounded-full transition-all duration-300"
                  style={{ width: `${summaryStatus.percentage ?? 0}%` }}
                />
              </div>
              <p className="text-xs text-gray-600">{summaryStatus.message || 'Выполняется...'}</p>
            </div>
          )}
          {summaryStatus && summaryStatus.status !== 'running' && (
            <p className="text-xs text-gray-600 mt-2">
              {summaryStatus.status === 'error' && <span className="text-red-600">Ошибка: {summaryStatus.error ?? ''}</span>}
              {summaryStatus.status === 'completed' && (
                <>
                  {summaryStatus.rows != null && `Готово: ${summaryStatus.rows.toLocaleString()} строк`}
                  {summaryStatus.elapsedMs != null && ` · Время: ${(summaryStatus.elapsedMs / 1000).toFixed(1)} с`}
                  {summaryStatus.completed_at && ` · Синхронизация: ${formatLastSync(summaryStatus.completed_at) ?? '—'}`}
                </>
              )}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
