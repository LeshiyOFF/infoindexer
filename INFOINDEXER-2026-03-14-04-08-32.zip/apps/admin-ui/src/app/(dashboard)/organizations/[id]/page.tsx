"use client";

import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { ArrowLeft, Building, MapPin, Calendar, Receipt, Phone, Mail, Globe, DownloadCloud, Loader2, TrendingUp, TrendingDown, DollarSign, Activity, PieChart as PieChartIcon, User, Users, CheckCircle2, ShieldAlert, ArrowUpRight, ArrowDownRight, Info, Search } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { translateRegion } from '@/lib/regions';
import { translateField } from '@/lib/translations';
import { toRubles, formatCurrency as fmtCurr, formatNumber as fmtNum } from '@/lib/currency';
import { abbreviateLegalForm } from '@/lib/companyName';
import { extractOkvedSubclassPrefix, getOkvedName } from '@/lib/okved';
import { getAuthHeaders } from '@/lib/api';
import { CompanyMeta, FinancialReport, ApiResponse } from 'shared';
import {
  Line, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ComposedChart, Area, LineChart
} from 'recharts';

/** Поля-коды в «Прочие сведения»: отображаются как код (синий фон), без графика и тренда */
const CODE_FIELDS = ['okpo', 'okopf', 'okogu', 'okfc', 'okfs', 'okato', 'oktmo'];

interface OSINTContacts {
  emails: { val: string; source: string; type?: 'direct' | 'official' | 'general' | 'verified' }[];
  phones: { val: string; source: string; type?: 'direct' | 'official' | 'general' | 'verified' }[];
  sourcesChecked?: { name: string; found: boolean; status: 'completed' | 'error' | 'skipped' }[];
  url?: string;
  director?: string;
  status?: string;
  address?: string;
  name?: string;
}

interface OrganizationDetails {
  data: FinancialReport[];
  meta: CompanyMeta | null;
  connections: Partial<CompanyMeta>[];
}

export default function OrganizationDashboardPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const [data, setData] = useState<FinancialReport[]>([]);
  const [meta, setMeta] = useState<CompanyMeta | null>(null);
  const [connections, setConnections] = useState<Partial<CompanyMeta>[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  const [chartHoverByField, setChartHoverByField] = useState<Record<string, number | null>>({});

  const [contacts, setContacts] = useState<OSINTContacts | null>(null);
  const [contactsStatus, setContactsStatus] = useState<'idle' | 'running' | 'completed' | 'error'>('idle');
  const [contactsStage, setContactsStage] = useState<string>('');

  const fetchContactsStatus = useCallback(async () => {
    try {
      const res = await fetch(`/api/organizations/${params.id}/contacts`, { headers: getAuthHeaders() });
      const json = await res.json() as ApiResponse<OSINTContacts> & { status: string; stage?: string; data?: OSINTContacts };
      setContactsStatus(json.status as 'idle' | 'running' | 'completed' | 'error');
      if (json.stage) setContactsStage(json.stage);

      if (json.status === 'completed' && json.data) {
        setContacts(json.data);
      }
    } catch {
      // ignore fetch errors
    }
  }, [params.id]);

  useEffect(() => {
    if (contactsStatus !== 'running') return;
    const interval = setInterval(fetchContactsStatus, 2000);
    return () => clearInterval(interval);
  }, [contactsStatus, fetchContactsStatus]);

  const fetchData = useCallback(async () => {
    try {
      const res = await fetch(`/api/organizations/${params.id}`, { headers: getAuthHeaders() });
      const json = await res.json() as ApiResponse<OrganizationDetails>;
      if (json.error) {
        setError(json.error);
      } else if (json.data) {
        setData(json.data.data);
        setMeta(json.data.meta);
        setConnections(json.data.connections || []);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка загрузки');
    }
    setLoading(false);
  }, [params.id]);

  useEffect(() => {
    fetchData();
    fetchContactsStatus();
  }, [fetchData, fetchContactsStatus]);

  const latest: FinancialReport = data[0] ?? { inn: '', year: 0 } as FinancialReport;
  const previous = data.length > 1 ? data[1] : null;
  
  const displayName = abbreviateLegalForm(contacts?.name || meta?.name) || `Организация ${latest.inn || latest.ogrn || params.id}`;
  const displayDirector = contacts?.director || meta?.director || 'Нет данных';
  const displayStatus = contacts?.status || meta?.status || 'Действующая';
    const displayAddress = contacts?.address || meta?.address || (translateRegion(latest.region || '') || 'Регион не указан');
  
  const charterCapitalRub = toRubles(latest.B_charter_capital);
  const revenueRub = toRubles(latest.PL_revenue);
  const age = parseFloat(String(latest.age ?? 0));

  const chartData = useMemo(() => {
    return [...data].reverse().map(d => ({
      ...d,
      yearStr: d.year + ' г.',
      revenue: toRubles(d.PL_revenue),
      netProfit: toRubles(d.PL_net_profit),
      assets: toRubles(d.B_assets),
      equity: toRubles(d.B_total_equity),
      liabilities: toRubles(d.B_assets) - toRubles(d.B_total_equity)
    }));
  }, [data]);

  const risks = useMemo(() => {
    if (!data.length) return [];
    const list = [];
    if (revenueRub === 0) list.push({ level: 'high', msg: 'Нулевая выручка за последний год' });
    if (age <= 1) list.push({ level: 'medium', msg: 'Компания создана менее года назад' });
    if (charterCapitalRub <= 10_000) list.push({ level: 'low', msg: 'Минимальный уставный капитал (10к ₽)' });
    if (displayStatus !== 'Действующая') list.push({ level: 'high', msg: `Статус: ${displayStatus}` });
    return list;
  }, [data.length, revenueRub, age, charterCapitalRub, displayStatus]);

  // Максимумы по годам для визуальных баров — вызывать ДО early return (правило хуков)
  const maxValues = useMemo(() => {
    if (!chartData.length) return { maxRev: 1, maxProfit: 1, maxAssets: 1 };
    const maxRev = Math.max(...chartData.map(d => d.revenue || 0), 1);
    const maxProfit = Math.max(...chartData.map(d => Math.abs(d.netProfit) || 0), 1);
    const maxAssets = Math.max(...chartData.map(d => d.assets || 0), 1);
    return { maxRev, maxProfit, maxAssets };
  }, [chartData]);

  const requestContacts = async () => {
    if (contactsStatus === 'running') return;
    setContactsStatus('running');
    try {
      const res = await fetch(`/api/organizations/${params.id}/contacts`, {
        method: 'POST',
        headers: getAuthHeaders()
      });
      if (!res.ok) throw new Error('Auth failed');
      setTimeout(fetchContactsStatus, 3000);
    } catch {
      setContactsStatus('error');
    }
  };

  const formatCurrencyForKpi = (val: string | number | null | undefined) => fmtCurr(val, true);

  if (loading) return (
    <div className="flex items-center justify-center h-[60vh]">
      <div className="flex flex-col items-center gap-4 text-gray-500">
        <Loader2 className="w-8 h-8 animate-spin text-gray-600" />
        <span className="font-medium">Анализируем финансовые показатели...</span>
      </div>
    </div>
  );

  if (error || data.length === 0) return (
    <div className="space-y-4">
      <button type="button" onClick={() => router.back()} className="inline-flex items-center gap-2 text-gray-700 hover:text-gray-900 font-medium">
        <ArrowLeft className="w-4 h-4" /> Назад к списку
      </button>
      <div className="bg-gray-100 text-gray-700 p-6 rounded-2xl border border-gray-200">{error || 'Организация не найдена'}</div>
    </div>
  );

  const calcGrowth = (curr: string | number | undefined, prev: string | number | undefined) => {
    const c = typeof curr === 'string' ? parseFloat(curr) : curr || 0;
    const p = typeof prev === 'string' ? parseFloat(prev) : prev || 0;
    if (!p || !c) return null;
    return ((c - p) / Math.abs(p)) * 100;
  };

  const KPICard = ({ title, value, growth, icon: Icon, colorClass, barPercent, barColor = 'bg-gray-900' }: { title: string; value: string | number | null | undefined; growth: number | null; icon: React.ComponentType<{ className?: string }>; colorClass: string; barPercent?: number; barColor?: string }) => (
    <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start mb-3">
        <div className={`p-3 rounded-xl ${colorClass}`}><Icon className="w-6 h-6" /></div>
        {growth !== null && (
          <div className={`flex items-center gap-1 text-xs font-bold ${growth >= 0 ? 'text-gray-700 bg-gray-100' : 'text-gray-600 bg-gray-100'} px-2.5 py-1 rounded-full`}>
            {growth >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            {Math.abs(growth).toFixed(1)}%
          </div>
        )}
      </div>
      <div>
        <p className="text-xs text-gray-500 font-bold uppercase tracking-wider mb-1">{title}</p>
        <h3 className="text-xl font-extrabold text-gray-900 mb-2">{formatCurrencyForKpi(value)}</h3>
        {barPercent !== undefined && barPercent > 0 && (
          <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
            <div className={`h-full rounded-full transition-all duration-500 ${barColor}`} style={{ width: `${Math.min(100, barPercent)}%` }} />
          </div>
        )}
      </div>
    </div>
  );

  const getGroupedFields = (row: FinancialReport) => {
    const balance: Record<string, string | number> = {};
    const pl: Record<string, string | number> = {};
    const cash: Record<string, string | number> = {};
    const purpose: Record<string, string | number> = {};
    const other: Record<string, string | number> = {};

    Object.keys(row).forEach(key => {
      if (['year', 'inn', 'ogrn', 'region', 'region_taxcode', 'creation_date', 'dissolution_date', 'age', 'eligible', 'okved', 'okved_section', 'lon', 'lat'].includes(key)) return;
      const val = row[key];
      if (val === null || val === undefined || val === 0 || val === '0') return;
      if (key.startsWith('B_')) balance[key] = val as string | number;
      else if (key.startsWith('PL_')) pl[key] = val as string | number;
      else if (key.startsWith('CF_') || key.startsWith('CFi_') || key.startsWith('CFo_')) cash[key] = val as string | number;
      else if (key.startsWith('PU_')) purpose[key] = val as string | number;
      else other[key] = val as string | number;
    });
    return { balance, pl, cash, purpose, other };
  };

  const defaultYear = data[0]?.year ?? 0;
  const { balance, pl, cash, purpose, other } = getGroupedFields(latest);

  return (
    <div className="space-y-6 pb-12 overflow-x-hidden min-w-0">
      <div className="flex items-center justify-between">
        <button type="button" onClick={() => router.back()} className="inline-flex items-center gap-2 text-gray-500 hover:text-gray-900 font-medium transition-colors">
          <ArrowLeft className="w-4 h-4" /> Назад к списку
        </button>
        <div className="flex items-center gap-2">
          {displayStatus.toLowerCase().includes('ликвид') ? (
            <span className="flex items-center gap-1.5 bg-gray-200 text-gray-800 px-3 py-1 rounded-full text-xs font-bold border border-gray-300">
              <ShieldAlert className="w-3.5 h-3.5" /> {displayStatus}
            </span>
          ) : (
            <span className="flex items-center gap-1.5 bg-gray-200 text-gray-800 px-3 py-1 rounded-full text-xs font-bold border border-gray-300">
              <CheckCircle2 className="w-3.5 h-3.5" /> {displayStatus}
            </span>
          )}
        </div>
      </div>

      {/* Main Identity Section */}
      <div className="bg-white p-4 sm:p-8 rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-start gap-4 sm:gap-6 min-w-0">
              <div className="w-16 h-16 sm:w-24 sm:h-24 bg-gradient-to-br from-gray-700 to-gray-800 text-white rounded-2xl sm:rounded-3xl flex items-center justify-center shrink-0 shadow-lg shadow-gray-200">
                <Building className="w-8 h-8 sm:w-12 sm:h-12" />
              </div>
              <div className="min-w-0 flex-1">
                <h1 className="text-xl sm:text-3xl font-black text-gray-900 leading-tight mb-3 uppercase break-words">{displayName}</h1>
                <div className="flex flex-col sm:flex-row sm:flex-wrap gap-2 sm:gap-3 max-w-full">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-0.5 sm:gap-2 text-sm bg-gray-50 px-3 py-2 rounded-xl border border-gray-100 min-w-0 max-w-full overflow-hidden">
                    <span className="flex items-center gap-2 text-gray-500 font-bold shrink-0">
                      <Receipt className="w-4 h-4 shrink-0" /> ИНН:
                    </span>
                    <span className="text-gray-900 font-mono break-all text-xs sm:text-sm">{latest.inn || 'Нет'}</span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-0.5 sm:gap-2 text-sm bg-gray-50 px-3 py-2 rounded-xl border border-gray-100 min-w-0 max-w-full overflow-hidden">
                    <span className="flex items-center gap-2 text-gray-500 font-bold shrink-0">
                      <Receipt className="w-4 h-4 shrink-0" /> ОГРН:
                    </span>
                    <span className="text-gray-900 font-mono break-all text-xs sm:text-sm">{latest.ogrn || 'Нет'}</span>
                  </div>
                  {(latest as Record<string, string>).okved && (
                    <>
                      <div className="flex flex-col gap-0.5 sm:gap-1 text-sm bg-gray-50 px-3 py-2 rounded-xl border border-gray-100 min-w-0 max-w-full overflow-hidden w-full sm:w-auto sm:max-w-sm">
                        <span className="flex items-center gap-2 text-gray-500 font-bold shrink-0">
                          <Activity className="w-4 h-4 shrink-0" /> ОКВЭД: <span className="text-gray-900 font-mono">{(latest as Record<string, string>).okved}</span>
                        </span>
                        {(() => {
                          const name = getOkvedName((latest as Record<string, string>).okved);
                          return name ? <span className="text-gray-600 font-normal text-xs break-words">{name}</span> : null;
                        })()}
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          const prefix = extractOkvedSubclassPrefix((latest as Record<string, string>).okved);
                          if (prefix) router.push(`/organizations?okved=${encodeURIComponent(prefix)}`);
                        }}
                        className="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold text-gray-700 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-xl transition-colors w-full sm:w-auto shrink-0"
                      >
                        <Search className="w-3.5 h-3.5 shrink-0" /> Похожие по ОКВЭД
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-gray-50">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-gray-100 rounded-lg text-gray-600"><User className="w-5 h-5" /></div>
                  <div>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Руководитель</p>
                    <p className="font-bold text-gray-800">{displayDirector}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-gray-100 rounded-lg text-gray-600"><MapPin className="w-5 h-5" /></div>
                  <div>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Юридический адрес</p>
                    <p className="font-bold text-gray-800 text-sm leading-relaxed">{displayAddress}</p>
                  </div>
                </div>
              </div>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-gray-100 rounded-lg text-gray-600"><Calendar className="w-5 h-5" /></div>
                  <div>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Дата регистрации</p>
                    <p className="font-bold text-gray-800">{latest.creation_date || 'Не указана'}</p>
                  </div>
                </div>
              </div>
            </div>
        </div>
      </div>

      {/* Контактная сетка — личные контакты директора по ФИО (между основной инфо и карточками выручки) */}
      <div className="bg-gray-900 rounded-3xl p-6 text-white flex flex-col justify-between shadow-xl">
            <div className="space-y-6">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <h3 className="text-xs font-black text-gray-400 uppercase tracking-[0.2em]">Личные контакты директора (OSINT по ФИО)</h3>
                  <p className="text-[9px] text-gray-500 mt-1 uppercase tracking-tighter">LinkedIn, VK по имени ≈ 80% личный • Сайт компании ≈ 0%</p>
                </div>
                {contacts?.sourcesChecked && (
                   <div className="flex gap-1">
                      {contacts.sourcesChecked.map((s, i) => (
                        <div key={i} title={`${s.name}: ${s.found ? 'Найдено' : 'Не найдено'}`} className={`w-1.5 h-1.5 rounded-full ${s.found ? 'bg-gray-500' : s.status === 'error' ? 'bg-gray-600' : 'bg-gray-700'}`}></div>
                      ))}
                   </div>
                )}
              </div>

              {contacts ? (
                <div className="space-y-6">
                  {contacts.phones.length > 0 && (
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 text-gray-400 text-[10px] font-black uppercase tracking-widest"><Phone className="w-3 h-3" /> Телефоны</div>
                      <div className="flex flex-col gap-2.5">
                        {contacts.phones.sort((a, b) => {
                          const order = { direct: 0, verified: 1, official: 2, general: 3 };
                          return (order[a.type || 'general'] || 9) - (order[b.type || 'general'] || 9);
                        }).map((p, i) => (
                          <div key={i} className={`flex flex-col bg-white/10 p-4 rounded-2xl border ${p.type === 'direct' ? 'border-gray-500/50 bg-gray-500/20' : 'border-white/5'} group/phone hover:bg-white/15 transition-all gap-2`}>
                            <div className="flex items-center justify-between">
                              <div className="flex flex-col">
                                <a href={`tel:${p.val}`} className={`font-mono text-base font-black ${p.type === 'direct' ? 'text-gray-300' : 'text-white'} hover:text-gray-400 transition-colors`}>{p.val}</a>
                                <div className="flex flex-wrap gap-1 mt-1.5">
                                  {p.source.split(', ').map((s, si) => (
                                    <span key={si} className="text-[8px] font-black uppercase bg-white/5 text-gray-400 px-1.5 py-0.5 rounded border border-white/5 tracking-widest">{s}</span>
                                  ))}
                                  {p.type === 'direct' && (
                                    <span className="text-[8px] font-bold text-gray-400 uppercase self-center">~80% личный</span>
                                  )}
                                </div>
                              </div>
                              {p.type === 'direct' && (
                                <div className="flex flex-col items-end">
                                  <span className="text-[8px] font-black uppercase bg-gray-600 text-white px-2 py-0.5 rounded">Найден по ФИО</span>
                                </div>
                              )}
                              </div>
                              <p className="text-[10px] text-gray-400 leading-tight font-medium bg-black/20 p-2 rounded-lg border border-white/5">
                              {p.type === 'direct'
                                ? `Найден по ФИО «${contacts.director}» в LinkedIn/VK/OSINT. Высокая вероятность личного контакта директора.`
                                : p.type === 'verified'
                                ? `С сайта компании. Юридический контакт, не личный — низкая релевантность для связи с ЛПР.`
                                : p.type === 'official'
                                ? `Из реестров (ФНС/ККТ). Контакт организации.`
                                : `Из открытых агрегаторов. Справочно.`
                              }
                              </p>                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  {contacts.emails.length > 0 && (
                    <div className="space-y-3 pt-2">
                      <div className="flex items-center gap-2 text-gray-400 text-[10px] font-black uppercase tracking-widest"><Mail className="w-3 h-3" /> Электронная почта</div>
                      <div className="flex flex-col gap-2">
                        {contacts.emails.map((e, i) => (
                          <div key={i} className="flex flex-col bg-white/10 p-3 rounded-xl border border-white/5 hover:bg-white/15 transition-all gap-1.5">
                            <div className="flex items-center justify-between">
                              <a href={`mailto:${e.val}`} className="text-[11px] text-white hover:text-gray-300 transition-colors truncate max-w-[150px] font-bold">{e.val}</a>
                              <div className="flex gap-1">
                                {e.source.split(', ').map((s, si) => (
                                  <span key={si} className="text-[8px] font-black uppercase bg-white/5 px-1.5 py-0.5 rounded text-gray-500 border border-white/5">{s}</span>
                                ))}
                              </div>
                            </div>
                            {e.type === 'direct' && (
                              <p className="text-[9px] text-gray-400 font-bold uppercase tracking-tighter">Личный email руководителя</p>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Sources Checked Map */}
                  <div className="pt-4 border-t border-white/5">
                    <p className="text-[9px] font-black text-gray-500 uppercase tracking-widest mb-3">Карта источников</p>
                    <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                      {contacts.sourcesChecked?.map((s, i) => (
                        <div key={i} className="flex items-center gap-2">
                          <div className={`w-1 h-1 rounded-full ${s.found ? 'bg-gray-500' : 'bg-gray-700'}`}></div>
                          <span className={`text-[9px] font-bold uppercase tracking-tight ${s.found ? 'text-gray-300' : 'text-gray-600'}`}>{s.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {contacts.emails.length === 0 && contacts.phones.length === 0 && (
                    <p className="text-gray-400 text-sm italic py-4">Личные контакты директора по ФИО не обнаружены</p>
                  )}
                  {contacts?.url && (
                    <a href={contacts.url.startsWith('http') ? contacts.url : `https://${contacts.url}`} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 text-[10px] font-bold text-gray-500 hover:text-white transition-colors mt-4">
                      <Globe className="w-3 h-3" /> ИСТОЧНИК ДАННЫХ: {(() => {
                        try {
                          return new URL(contacts.url.startsWith('http') ? contacts.url : `https://${contacts.url}`).hostname;
                        } catch {
                          return contacts.url;
                        }
                      })()}
                    </a>
                  )}
                </div>
              ) : (
                <div className="py-6 space-y-6">
                  {contactsStatus === 'running' ? (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-widest text-gray-400">
                        <span>Прогресс поиска</span>
                        <span>{(() => {
                          const match = contactsStage.match(/(\d)\/(\d)/);
                          if (match) return `${Math.round((parseInt(match[1]) / parseInt(match[2])) * 100)}%`;
                          return '...';
                        })()}</span>
                      </div>
                      <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-gray-600 transition-all duration-500" 
                          style={{ width: (() => {
                            const match = contactsStage.match(/(\d+)\/(\d+)/);
                            if (match) return `${(parseInt(match[1]) / parseInt(match[2])) * 100}%`;
                            return '5%';
                          })() }}
                        ></div>
                      </div>
                      <div className="flex items-start gap-3 p-4 bg-white/5 rounded-2xl border border-white/5 animate-pulse">
                        <Loader2 className="w-4 h-4 animate-spin text-gray-400 shrink-0 mt-0.5" />
                        <div>
                          <p className="text-xs font-bold text-white leading-tight">{contactsStage || 'Инициализация...'}</p>
                          <p className="text-[9px] font-medium text-gray-500 mt-1 uppercase tracking-tighter">Поиск по ФИО «{displayDirector}». LinkedIn, VK — личные контакты</p>
                        </div>
                      </div>
                      
                      <div className="flex flex-wrap gap-1 opacity-60">
                        {Array.from({ length: 21 }).map((_, i) => {
                          const match = contactsStage.match(/(\d+)\/(\d+)/);
                          const currentStep = match ? parseInt(match[1]) : 0;
                          const isDone = (i + 1) < currentStep;
                          const isCurrent = (i + 1) === currentStep;
                          return (
                            <div key={i} className={`w-1.5 h-1.5 rounded-full ${isDone ? 'bg-gray-500' : isCurrent ? 'bg-gray-400' : 'bg-gray-700'}`} title={`Этап ${i + 1}/21`} />
                          );
                        })}
                      </div>
                    </div>
                  ) : (
                    <div className="text-center">
                      <p className="text-gray-400 text-sm mb-6">Личные контакты директора (телефон/email по ФИО) не загружены.</p>
                      <button 
                        onClick={requestContacts}
                        className="w-full bg-white text-gray-900 py-3 rounded-2xl text-sm font-black hover:bg-gray-100 transition-all flex items-center justify-center gap-2 shadow-lg"
                      >
                        <DownloadCloud className="w-4 h-4" /> Обогатить данные
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

      {/* Connections & Risks Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {connections.length > 0 && (
          <div className={`${risks.length > 0 ? 'lg:col-span-2' : 'lg:col-span-3'} bg-white p-8 rounded-3xl shadow-sm border border-gray-100`}>
            <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest mb-6 flex items-center gap-2">
              <Users className="w-4 h-4 text-gray-600" /> Связанные организации
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {connections.map((conn: Partial<CompanyMeta>) => (
                <Link key={conn.inn} href={`/organizations/${conn.inn}`} className="p-4 rounded-2xl border-2 border-gray-200 bg-gray-50/30 hover:bg-gray-50 hover:border-gray-400 transition-all group">
                  <p className="text-xs font-black text-gray-900 uppercase truncate mb-1 group-hover:text-gray-800 transition-colors" title={conn.name}>{abbreviateLegalForm(conn.name) || conn.name}</p>
                  <div className="flex justify-between items-center text-[10px] font-bold text-gray-500">
                    <span>ИНН: {conn.inn}</span>
                    <span className="bg-white px-2 py-0.5 rounded-full border border-gray-100">{conn.status}</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {risks.length > 0 && (
          <div className={`${connections.length > 0 ? 'lg:col-span-1' : 'lg:col-span-3'} bg-white p-8 rounded-3xl shadow-sm border border-gray-100`}>
            <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest mb-6 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-gray-600" /> Анализ рисков
            </h3>
            <div className="space-y-3">
              {risks.map((risk, i) => (
                <div key={i} className={`flex items-start gap-3 p-3 rounded-xl border ${
                  risk.level === 'high' ? 'bg-gray-200 border-gray-300 text-gray-800' : 
                  risk.level === 'medium' ? 'bg-gray-100 border-gray-200 text-gray-700' : 
                  'bg-gray-50 border-gray-100 text-gray-600'
                }`}>
                  <div className="mt-0.5">
                    {risk.level === 'high' ? <ShieldAlert className="w-4 h-4" /> : <Activity className="w-4 h-4" />}
                  </div>
                  <p className="text-xs font-bold leading-tight">{risk.msg}</p>
                </div>
              ))}
              <div className="pt-4 mt-4 border-t border-gray-50">
                <p className="text-[10px] font-medium text-gray-400 leading-relaxed italic">
                  * Данный анализ носит справочный характер и не является окончательным вердиктом о благонадежности.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Financial KPIs с визуальными индикаторами масштаба */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <KPICard 
          title="Выручка" value={latest.PL_revenue} growth={calcGrowth(latest.PL_revenue, previous?.PL_revenue)} 
          icon={DollarSign} colorClass="bg-gray-100 text-gray-600" barColor="bg-gray-900"
          barPercent={maxValues.maxRev ? (toRubles(latest.PL_revenue) / maxValues.maxRev) * 100 : undefined}
        />
        <KPICard 
          title="Чистая прибыль" value={latest.PL_net_profit} growth={calcGrowth(latest.PL_net_profit, previous?.PL_net_profit)} 
          icon={Activity} colorClass="bg-gray-50 text-gray-600" barColor={toRubles(latest.PL_net_profit) >= 0 ? 'bg-gray-500' : 'bg-gray-700'}
          barPercent={maxValues.maxProfit ? (Math.abs(toRubles(latest.PL_net_profit)) / maxValues.maxProfit) * 100 : undefined}
        />
        <KPICard 
          title="Чистые активы" value={latest.NA_net_assets || latest.B_assets} growth={calcGrowth(latest.NA_net_assets || latest.B_assets, previous?.NA_net_assets || previous?.B_assets)} 
          icon={ShieldAlert} colorClass="bg-gray-100 text-gray-600" barColor="bg-gray-800"
          barPercent={maxValues.maxAssets ? (parseFloat(String(latest.NA_net_assets || latest.B_assets || 0)) / maxValues.maxAssets) * 100 : undefined}
        />
        <KPICard 
          title="Собственный капитал" value={latest.B_total_equity} growth={calcGrowth(latest.B_total_equity, previous?.B_total_equity)} 
          icon={Users} colorClass="bg-gray-100 text-gray-600" barColor="bg-gray-700"
          barPercent={maxValues.maxAssets ? (parseFloat(String(latest.B_total_equity || 0)) / maxValues.maxAssets) * 100 : undefined}
        />
      </div>

      {/* Динамика по годам — компактная и наглядная */}
      {chartData.length >= 1 && (
        <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
          <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest mb-2">Динамика по отчетным годам</h3>
          <p className="text-xs text-gray-500 mb-6">Выручка (столбцы), чистая прибыль (линия). Наведите на точку для деталей.</p>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                <XAxis dataKey="yearStr" axisLine={false} tickLine={false} tick={{fill: '#6B7280', fontSize: 12, fontWeight: 700}} dy={10} />
                <YAxis 
                  tickFormatter={(val: number) => {
                    if (val >= 1e9) return (val / 1e9).toFixed(1) + ' млрд';
                    if (val >= 1e6) return (val / 1e6).toFixed(0) + ' млн';
                    return (val / 1e3).toFixed(0) + ' тыс';
                  }} 
                  axisLine={false} tickLine={false} tick={{fill: '#6B7280', fontSize: 11}} 
                  dx={-5} width={55}
                />
                <Tooltip 
                  formatter={(v: string | number | undefined) => [fmtNum(v ?? 0, false) + ' ₽']}
                  contentStyle={{ borderRadius: '12px', border: '1px solid #E5E7EB', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)', padding: '12px 16px', fontSize: '13px' }}
                  labelFormatter={(label) => `Отчётный год: ${label}`}
                />
                <Bar dataKey="revenue" name="Выручка" fill="#374151" radius={[6, 6, 0, 0]} maxBarSize={48} />
                <Line type="monotone" dataKey="netProfit" name="Чистая прибыль" stroke="#4B5563" strokeWidth={3} dot={{r: 5, fill: '#4B5563', strokeWidth: 2, stroke: '#fff'}} strokeDasharray="" />
                <Legend wrapperStyle={{ paddingTop: 16 }} formatter={(value) => <span className="text-xs font-bold text-gray-600">{value}</span>} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Активы и структура капитала */}
      {chartData.length > 1 && (
        <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
          <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest mb-2">Активы и заёмный капитал</h3>
          <p className="text-xs text-gray-500 mb-6">Суммарные активы (заливка), заёмные средства (пунктир).</p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                <XAxis dataKey="yearStr" axisLine={false} tickLine={false} tick={{fill: '#6B7280', fontSize: 12, fontWeight: 700}} dy={10} />
                <YAxis 
                  tickFormatter={(val: number) => (val >= 1e9 ? (val / 1e9).toFixed(1) + ' млрд' : (val >= 1e6 ? (val / 1e6).toFixed(0) + ' млн' : (val / 1e3).toFixed(0) + ' тыс'))} 
                  axisLine={false} tickLine={false} tick={{fill: '#6B7280', fontSize: 11}} dx={-5} width={55}
                />
                <Tooltip formatter={(v: string | number | undefined) => [fmtNum(v ?? 0, false) + ' ₽']} contentStyle={{ borderRadius: '12px', border: '1px solid #E5E7EB', boxShadow: '0 4px 6px rgba(0,0,0,0.1)', padding: '12px 16px' }} />
                <Area type="monotone" dataKey="assets" name="Активы" stroke="#6B7280" fill="url(#colorAssets)" strokeWidth={2} />
                <Line type="monotone" dataKey="liabilities" name="Заёмный капитал" stroke="#4B5563" strokeWidth={2} strokeDasharray="5 5" dot={{r: 4}} />
                <defs>
                  <linearGradient id="colorAssets" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#6B7280" stopOpacity={0.3}/>
                    <stop offset="100%" stopColor="#6B7280" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <Legend wrapperStyle={{ paddingTop: 12 }} formatter={(value) => <span className="text-xs font-bold text-gray-600">{value}</span>} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Бухгалтерская отчётность — детальный просмотр */}
      <div className="bg-white rounded-3xl shadow-sm border-2 border-gray-200 overflow-hidden">
        <div className="p-6 border-b-2 border-gray-200 bg-gray-50/50">
          <h2 className="text-xl font-extrabold text-gray-900 flex items-center gap-2">
            Бухгалтерская отчетность (ФНС)
            <span className="px-2 py-0.5 bg-gray-200 text-gray-700 text-xs rounded-full font-bold">Аналитика</span>
          </h2>
          <p className="text-sm text-gray-500 mt-1 font-medium">Наведите на мини-график — сумма обновится в тексте рядом; без курсора — значение за последний год</p>
        </div>

        <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
          {[
            { label: 'Результаты деятельности', data: pl, iconClass: 'bg-gray-100 text-gray-600', icon: Activity },
            { label: 'Внеоборотные и оборотные активы', data: balance, iconClass: 'bg-gray-100 text-gray-600', icon: Building },
            { label: 'Движение денежных средств', data: cash, iconClass: 'bg-gray-100 text-gray-600', icon: DollarSign },
            { label: 'Целевое использование средств', data: purpose, iconClass: 'bg-gray-100 text-gray-600', icon: TrendingUp },
            { label: 'Прочие сведения', data: other, iconClass: 'bg-gray-100 text-gray-600', icon: PieChartIcon },
          ].filter(g => Object.keys(g.data).length > 0).map((group, idx) => (
            <div key={idx} className="flex flex-col bg-white rounded-2xl border-2 border-gray-200 overflow-hidden">
              <div className="p-4 border-b border-gray-100 bg-gray-50/50 flex items-center gap-3">
                <div className={`p-2 rounded-lg ${group.iconClass}`}><group.icon className="w-4 h-4" /></div>
                <h3 className="font-bold text-gray-800 uppercase tracking-wide text-sm">{group.label}</h3>
              </div>
              <div className="p-4 space-y-0">
                {Object.entries(group.data).map(([k]) => {
                  const isCodeField = group.label === 'Прочие сведения' && CODE_FIELDS.includes(k);
                  const displayYearForField = chartHoverByField[k] ?? defaultYear;
                  const yearDataForField = data.find(d => d.year === displayYearForField) || latest;
                  const displayVal = (yearDataForField as Record<string, unknown>)[k] as string | number | null | undefined;
                  const numVal = Number(displayVal);
                  const rubVal = toRubles(displayVal);
                  const prevYearData = data.find(d => d.year === displayYearForField - 1);
                  const prevVal = prevYearData ? toRubles((prevYearData as Record<string, unknown>)[k] as string | number | null | undefined) : null;
                  const change = prevVal !== null && prevVal !== 0 ? ((rubVal - prevVal) / Math.abs(prevVal)) * 100 : null;
                  const trendData = [...data].sort((a, b) => a.year - b.year).map(d => ({ v: toRubles((d as Record<string, unknown>)[k] as string | number | null | undefined), i: d.year }));
                  const isNegative = numVal < 0;

                  // «Прочие сведения»: коды — синий стиль без графика; остальное — как раньше
                  if (isCodeField) {
                    return (
                      <div key={k} className="flex items-center justify-between py-4 border-b border-gray-100 last:border-0 hover:bg-gray-50/50 transition-colors px-2 rounded-lg">
                        <span className="text-gray-600 text-sm font-medium flex items-center gap-2">
                          {translateField(k)}
                          <Info className="w-3.5 h-3.5 text-gray-300 cursor-help" />
                        </span>
                        <span className="font-mono font-semibold text-gray-700 bg-gray-100 px-2 py-1 rounded text-sm">
                          {String(displayVal ?? '—')}
                        </span>
                      </div>
                    );
                  }

                  return (
                    <div key={k} className="flex flex-col py-3 border-b border-gray-100 last:border-0 hover:bg-gray-50/50 transition-colors px-2 rounded-lg">
                      <div className="flex items-center justify-between gap-3 mb-1">
                        <span className="text-sm font-medium text-gray-500 truncate" title={k}>{translateField(k)}</span>
                        <div className="flex items-center gap-3 shrink-0 w-[9rem]">
                          {trendData.length > 1 && (
                            <div
                              className="w-14 h-5 hidden sm:block cursor-crosshair shrink-0"
                              onMouseMove={(e) => {
                                const rect = e.currentTarget.getBoundingClientRect();
                                const x = e.clientX - rect.left;
                                const ratio = Math.max(0, Math.min(1, x / rect.width));
                                const idx = Math.min(Math.floor(ratio * trendData.length), trendData.length - 1);
                                const point = trendData[idx];
                                if (point) {
                                  const year = point.i;
                                  setChartHoverByField(prev => (prev[k] === year ? prev : { ...prev, [k]: year }));
                                }
                              }}
                              onMouseLeave={() => setChartHoverByField(prev => ({ ...prev, [k]: null }))}
                            >
                              <ResponsiveContainer width="100%" height="100%">
                                <LineChart data={trendData.map((t) => ({ v: t.v, year: t.i }))}>
                                  <Line
                                    type="monotone"
                                    dataKey="v"
                                    stroke={isNegative ? '#6B7280' : '#4b5563'}
                                    strokeWidth={2}
                                    dot={false}
                                    activeDot={false}
                                  />
                                </LineChart>
                              </ResponsiveContainer>
                            </div>
                          )}
                          <span className={`text-sm font-bold tabular-nums text-right flex-1 min-w-0 truncate ${isNegative ? 'text-gray-600' : 'text-gray-900'}`}>
                            {fmtNum(displayVal, true)}
                          </span>
                        </div>
                      </div>
                      <div className="min-h-[1.25rem] flex items-center">
                        {change !== null ? (
                          <div className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider">
                            {change >= 0 ? (
                              <span className="text-gray-700 flex items-center"><ArrowUpRight size={12}/> +{change.toFixed(1)}%</span>
                            ) : (
                              <span className="text-gray-600 flex items-center"><ArrowDownRight size={12}/> {change.toFixed(1)}%</span>
                            )}
                            <span className="text-gray-400 font-normal">к прошлому году</span>
                          </div>
                        ) : null}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}
