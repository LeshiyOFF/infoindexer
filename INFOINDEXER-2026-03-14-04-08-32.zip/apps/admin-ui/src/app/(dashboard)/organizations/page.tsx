"use client";

import { useEffect, useState, useCallback, useRef } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { regionMap } from '@/lib/regions';
import { getAuthHeaders } from '@/lib/api';
import type { CompanyMeta } from 'shared';
import { useBatch } from '@/contexts/BatchContext';
import { OrganizationsFilters } from './components/OrganizationsFilters';
import { OrganizationsCardList } from './components/OrganizationsCardList';
import { OrganizationsTable } from './components/OrganizationsTable';

const FILTERS_PERSIST_KEY = 'org-filters-persist';
const SHOW_FILTERS_KEY = 'org-show-filters';

function formatCurrency(val: number | undefined): string {
  const rub = (val || 0) * 1000;
  if (!rub) return '-';
  if (rub >= 1e9) return (rub / 1e9).toFixed(1) + ' млрд ₽';
  if (rub >= 1e6) return (rub / 1e6).toFixed(1) + ' млн ₽';
  return rub.toLocaleString('ru-RU') + ' ₽';
}

export default function OrganizationsPage() {
  const searchParams = useSearchParams();
  const router = useRouter();

  const parseInitial = useCallback(() => {
    const fromUrl = {
      page: Math.max(1, parseInt(searchParams.get('page') || '1')),
      search: searchParams.get('search') || '',
      sortBy: searchParams.get('sortBy') || 'records_count',
      sortOrder: (searchParams.get('sortOrder') || 'DESC') as 'ASC' | 'DESC',
      region: searchParams.get('region') || '',
      okved: searchParams.get('okved') || '',
      minRev: Math.max(0, Math.min(10000, parseInt(searchParams.get('minRevenue') || '0') || 0)),
      maxRev: Math.max(0, Math.min(10000, parseInt(searchParams.get('maxRevenue') || '10000') || 10000)),
      minA: Math.max(0, Math.min(50, parseInt(searchParams.get('minAge') || '0') || 0)),
      maxA: Math.max(0, Math.min(50, parseInt(searchParams.get('maxAge') || '50') || 50)),
      hasGeo: searchParams.get('hasGeo') === 'true',
      hasDir: searchParams.get('hasDirector') === 'true',
      hasName: searchParams.get('hasName') === 'true'
    };
    const hasUrlParams = searchParams.toString().length > 0;
    if (hasUrlParams) return fromUrl;
    try {
      const stored = sessionStorage.getItem(FILTERS_PERSIST_KEY);
      if (stored) {
        const p = JSON.parse(stored) as Record<string, unknown>;
        return {
          page: Math.max(1, Math.min(1000, Number(p.page) || 1)),
          search: typeof p.search === 'string' ? p.search : fromUrl.search,
          sortBy: typeof p.sortBy === 'string' ? p.sortBy : fromUrl.sortBy,
          sortOrder: (p.sortOrder === 'ASC' || p.sortOrder === 'DESC' ? p.sortOrder : fromUrl.sortOrder) as 'ASC' | 'DESC',
          region: typeof p.region === 'string' ? p.region : fromUrl.region,
          okved: typeof p.okved === 'string' ? p.okved : fromUrl.okved,
          minRev: Math.max(0, Math.min(10000, Number(p.minRevenue) ?? fromUrl.minRev)),
          maxRev: Math.max(0, Math.min(10000, Number(p.maxRevenue) ?? fromUrl.maxRev)),
          minA: Math.max(0, Math.min(50, Number(p.minAge) ?? fromUrl.minA)),
          maxA: Math.max(0, Math.min(50, Number(p.maxAge) ?? fromUrl.maxA)),
          hasGeo: Boolean(p.hasGeo),
          hasDir: Boolean(p.hasDirector),
          hasName: Boolean(p.hasName)
        };
      }
    } catch (e) {
      console.warn('Организации: ошибка sessionStorage/parse', e);
    }
    return fromUrl;
  }, [searchParams]);

  const [data, setData] = useState<CompanyMeta[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({ total: 0, limit: 50, totalPages: 0 });
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [sortBy, setSortBy] = useState('records_count');
  const [sortOrder, setSortOrder] = useState('DESC');
  const [regionFilter, setRegionFilter] = useState('');
  const [okvedFilter, setOkvedFilter] = useState('');
  const [minRevenue, setMinRevenue] = useState(0);
  const [maxRevenue, setMaxRevenue] = useState(10000);
  const [minAge, setMinAge] = useState(0);
  const [maxAge, setMaxAge] = useState(50);
  const [hasGeoFilter, setHasGeoFilter] = useState(false);
  const [hasDirectorFilter, setHasDirectorFilter] = useState(false);
  const [hasNameFilter, setHasNameFilter] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [presetInfoOpen, setPresetInfoOpen] = useState(false);

  const REVENUE_MAX = 10000;
  const AGE_MAX = 50;

  const { batchItems, toggleBatch, toggleBatchPage } = useBatch();
  const batchInnSet = new Set(batchItems.map((b) => b.inn));
  const presetInfoRef = useRef<HTMLDivElement>(null);

  const pageItems = data
    .map((r) => ({ inn: r.inn || r.ogrn || '', name: r.name || '' }))
    .filter((x) => x.inn);

  const [hydrationDone, setHydrationDone] = useState(false);
  const fetchIdRef = useRef(0);
  const hydratedRef = useRef(false);

  useEffect(() => {
    if (hydratedRef.current) return;
    hydratedRef.current = true;
    const init = parseInitial();
    setPage(init.page);
    setSearch(init.search);
    setDebouncedSearch(init.search);
    setSortBy(init.sortBy);
    setSortOrder(init.sortOrder);
    setRegionFilter(init.region);
    setOkvedFilter(init.okved);
    setMinRevenue(init.minRev);
    setMaxRevenue(init.maxRev);
    setMinAge(init.minA);
    setMaxAge(init.maxA);
    setHasGeoFilter(init.hasGeo);
    setHasDirectorFilter(init.hasDir);
    setHasNameFilter(init.hasName);
    try {
      const sf = sessionStorage.getItem(SHOW_FILTERS_KEY);
      setShowFilters(sf === 'true');
    } catch (e) {
      console.warn('Организации: ошибка sessionStorage/init', e);
    }
    setHydrationDone(true);
  }, [parseInitial]);

  const syncToUrl = useCallback(
    (updates: Partial<{ page: number; search: string; sortBy: string; sortOrder: string; region: string; okved: string; minRevenue: number; maxRevenue: number; minAge: number; maxAge: number; hasGeo: boolean; hasDirector: boolean; hasName: boolean }>) => {
      const p = updates.page ?? page;
      const s = updates.search ?? search;
      const sb = updates.sortBy ?? sortBy;
      const so = updates.sortOrder ?? sortOrder;
      const r = updates.region ?? regionFilter;
      const ok = updates.okved ?? okvedFilter;
      const minR = updates.minRevenue ?? minRevenue;
      const maxR = updates.maxRevenue ?? maxRevenue;
      const minA = updates.minAge ?? minAge;
      const maxA = updates.maxAge ?? maxAge;
      const hg = updates.hasGeo ?? hasGeoFilter;
      const hd = updates.hasDirector ?? hasDirectorFilter;
      const hn = updates.hasName ?? hasNameFilter;
      const params = new URLSearchParams();
      if (p > 1) params.set('page', p.toString());
      if (s) params.set('search', s);
      if (sb !== 'records_count') params.set('sortBy', sb);
      if (so !== 'DESC') params.set('sortOrder', so);
      if (r) params.set('region', r);
      if (ok) params.set('okved', ok);
      if (minR > 0) params.set('minRevenue', minR.toString());
      if (maxR < 10000) params.set('maxRevenue', maxR.toString());
      if (minA > 0) params.set('minAge', minA.toString());
      if (maxA < 50) params.set('maxAge', maxA.toString());
      if (hg) params.set('hasGeo', 'true');
      if (hd) params.set('hasDirector', 'true');
      if (hn) params.set('hasName', 'true');
      const q = params.toString();
      router.replace(q ? `/organizations?${q}` : '/organizations', { scroll: false });
      try {
        sessionStorage.setItem(
          FILTERS_PERSIST_KEY,
          JSON.stringify({ page: p, search: s, sortBy: sb, sortOrder: so, region: r, okved: ok, minRevenue: minR, maxRevenue: maxR, minAge: minA, maxAge: maxA, hasGeo: hg, hasDirector: hd, hasName: hn })
        );
      } catch (e) {
        console.warn('Организации: ошибка sessionStorage/syncToUrl', e);
      }
    },
    [page, search, sortBy, sortOrder, regionFilter, okvedFilter, minRevenue, maxRevenue, minAge, maxAge, hasGeoFilter, hasDirectorFilter, hasNameFilter, router]
  );

  useEffect(() => {
    if (!hydrationDone) return;
    syncToUrl({ search: debouncedSearch });
  }, [hydrationDone, page, debouncedSearch, sortBy, sortOrder, regionFilter, okvedFilter, minRevenue, maxRevenue, minAge, maxAge, hasGeoFilter, hasDirectorFilter, hasNameFilter, syncToUrl]);

  useEffect(() => {
    try {
      sessionStorage.setItem(SHOW_FILTERS_KEY, showFilters ? 'true' : 'false');
    } catch (e) {
      console.warn('Организации: ошибка sessionStorage/showFilters', e);
    }
  }, [showFilters]);

  const regionsList = Object.entries(regionMap)
    .map(([key, val]) => ({ id: key, name: val }))
    .sort((a, b) => a.name.localeCompare(b.name));

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearch(search);
      setPage(1);
    }, 400);
    return () => clearTimeout(handler);
  }, [search]);

  const fetchData = useCallback(
    async (signal?: AbortSignal) => {
      const id = ++fetchIdRef.current;
      const start = Date.now();
      setLoading(true);
      try {
        const params: Record<string, string> = {
          page: page.toString(),
          limit: '50',
          search: debouncedSearch,
          sortBy,
          sortOrder,
          region: regionFilter,
          okved: okvedFilter,
          hasGeo: hasGeoFilter ? 'true' : '',
          minRevenue: minRevenue > 0 ? minRevenue.toString() : '',
          maxRevenue: maxRevenue < REVENUE_MAX ? maxRevenue.toString() : '',
          minAge: minAge > 0 ? minAge.toString() : '',
          maxAge: maxAge < AGE_MAX ? maxAge.toString() : '',
          hasDirector: hasDirectorFilter ? 'true' : '',
          hasName: hasNameFilter ? 'true' : ''
        };
        const res = await fetch(`/api/organizations?${new URLSearchParams(params).toString()}`, {
          cache: 'no-store',
          signal,
          headers: getAuthHeaders()
        });
        const json = await res.json();
        if (id !== fetchIdRef.current || signal?.aborted) return;
        if (!res.ok || json.error) {
          setData([]);
          setPagination({ total: 0, limit: 50, totalPages: 0 });
          return;
        }
        setData(json.data ? [...json.data] : []);
        setPagination(json.pagination || { total: 0, limit: 50, totalPages: 0 });
      } catch (e) {
        if ((e as DOMException)?.name === 'AbortError') return;
        if (id !== fetchIdRef.current) return;
        console.error(e);
        setData([]);
      } finally {
        if (id === fetchIdRef.current && !signal?.aborted) {
          const elapsed = Date.now() - start;
          if (elapsed < 220) await new Promise((r) => setTimeout(r, 220 - elapsed));
          setLoading(false);
        }
      }
    },
    [page, debouncedSearch, sortBy, sortOrder, regionFilter, okvedFilter, hasGeoFilter, hasDirectorFilter, hasNameFilter, minRevenue, maxRevenue, minAge, maxAge]
  );

  useEffect(() => {
    const ac = new AbortController();
    fetchData(ac.signal);
    return () => ac.abort();
  }, [fetchData]);

  const handleSort = (field: string) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'ASC' ? 'DESC' : 'ASC');
    } else {
      setSortBy(field);
      setSortOrder('DESC');
    }
    setLoading(true);
    setPage(1);
  };

  const goToPage = (updater: (p: number) => number) => {
    const nextPage = updater(page);
    if (nextPage === page) return;
    setLoading(true);
    setPage(nextPage);
  };

  const applyPreset = (type: string) => {
    if (type === 'real_companies') {
      const preset = { minRev: 200, maxRev: REVENUE_MAX, minA: 1, maxA: AGE_MAX, hasDir: true, hasGeo: false };
      const alreadyMatch =
        minRevenue === preset.minRev &&
        maxRevenue === preset.maxRev &&
        minAge === preset.minA &&
        maxAge === preset.maxA &&
        hasDirectorFilter === preset.hasDir &&
        hasGeoFilter === preset.hasGeo;
      if (alreadyMatch) return;
      setMinRevenue(200);
      setMaxRevenue(REVENUE_MAX);
      setMinAge(1);
      setMaxAge(AGE_MAX);
      setHasDirectorFilter(true);
      setHasGeoFilter(false);
    } else if (type === 'new_ones') {
      const preset = { minRev: 0, maxRev: REVENUE_MAX, minA: 0, maxA: AGE_MAX, hasDir: false, hasGeo: false };
      const alreadyMatch =
        minRevenue === preset.minRev &&
        maxRevenue === preset.maxRev &&
        minAge === preset.minA &&
        maxAge === preset.maxA &&
        hasDirectorFilter === preset.hasDir &&
        hasGeoFilter === preset.hasGeo;
      if (alreadyMatch) return;
      setMinRevenue(0);
      setMaxRevenue(REVENUE_MAX);
      setMinAge(0);
      setMaxAge(AGE_MAX);
      setHasDirectorFilter(false);
      setHasGeoFilter(false);
    }
    setLoading(true);
    setPage(1);
  };

  const hasActiveFilters = Boolean(
    regionFilter ||
    okvedFilter ||
    hasGeoFilter ||
    hasDirectorFilter ||
    hasNameFilter ||
    minRevenue > 0 ||
    maxRevenue < REVENUE_MAX ||
    minAge > 0 ||
    maxAge < AGE_MAX
  );

  const resetFilters = () => {
    if (!hasActiveFilters) return;
    setLoading(true);
    setRegionFilter('');
    setOkvedFilter('');
    setMinRevenue(0);
    setMaxRevenue(REVENUE_MAX);
    setMinAge(0);
    setMaxAge(AGE_MAX);
    setHasGeoFilter(false);
    setHasDirectorFilter(false);
    setHasNameFilter(false);
    setPage(1);
  };

  return (
    <div className="space-y-6">
      <OrganizationsFilters
        search={search}
        onSearchChange={setSearch}
        showFilters={showFilters}
        onShowFiltersToggle={() => setShowFilters(!showFilters)}
        hasActiveFilters={hasActiveFilters}
        regionFilter={regionFilter}
        onRegionChange={(id) => {
          if (id === regionFilter) return;
          setLoading(true);
          setRegionFilter(id);
          setPage(1);
        }}
        okvedFilter={okvedFilter}
        onOkvedChange={(code) => {
          if (code === okvedFilter) return;
          setLoading(true);
          setOkvedFilter(code);
          setPage(1);
        }}
        minRevenue={minRevenue}
        maxRevenue={maxRevenue}
        onRevenueChange={([lo, hi]) => {
          if (lo === minRevenue && hi === maxRevenue) return;
          setLoading(true);
          setMinRevenue(lo);
          setMaxRevenue(hi);
          setPage(1);
        }}
        minAge={minAge}
        maxAge={maxAge}
        onAgeChange={([lo, hi]) => {
          if (lo === minAge && hi === maxAge) return;
          setLoading(true);
          setMinAge(lo);
          setMaxAge(hi);
          setPage(1);
        }}
        hasGeoFilter={hasGeoFilter}
        onHasGeoChange={(v) => {
          if (v === hasGeoFilter) return;
          setLoading(true);
          setHasGeoFilter(v);
          setPage(1);
        }}
        hasDirectorFilter={hasDirectorFilter}
        onHasDirectorChange={(v) => {
          if (v === hasDirectorFilter) return;
          setLoading(true);
          setHasDirectorFilter(v);
          setPage(1);
        }}
        hasNameFilter={hasNameFilter}
        onHasNameChange={(v) => {
          if (v === hasNameFilter) return;
          setLoading(true);
          setHasNameFilter(v);
          setPage(1);
        }}
        onApplyPreset={applyPreset}
        onResetFilters={resetFilters}
        regionsList={regionsList}
        presetInfoRef={presetInfoRef}
        presetInfoOpen={presetInfoOpen}
        onPresetInfoOpenChange={setPresetInfoOpen}
        totalCount={pagination.total}
        totalPages={pagination.totalPages}
      />

      <div className="bg-white rounded-2xl lg:rounded-3xl shadow-lg border border-gray-200 overflow-hidden">
        <div className="lg:hidden p-4 space-y-4">
          <OrganizationsCardList
            data={data}
            loading={loading}
            pageItems={pageItems}
            batchInnSet={batchInnSet}
            formatCurrency={formatCurrency}
            toggleBatch={toggleBatch}
            toggleBatchPage={toggleBatchPage}
          />
        </div>
        <OrganizationsTable
          data={data}
          loading={loading}
          page={page}
          pagination={pagination}
          pageItems={pageItems}
          batchInnSet={batchInnSet}
          sortBy={sortBy}
          sortOrder={sortOrder}
          formatCurrency={formatCurrency}
          handleSort={handleSort}
          goToPage={goToPage}
          toggleBatch={toggleBatch}
          toggleBatchPage={toggleBatchPage}
        />
      </div>
    </div>
  );
}
