"use client";

import { Filter, Info, Search } from 'lucide-react';
import { createPortal } from 'react-dom';
import { DualRangeSlider } from '@/components/ui/DualRangeSlider';
import { RegionCombobox } from '@/components/ui/RegionCombobox';
import { OkvedCombobox } from '@/components/ui/OkvedCombobox';
import { PresetTooltipPortal } from './PresetTooltipPortal';

const REVENUE_MAX = 10000;
const AGE_MAX = 50;

export interface RegionOption {
  id: string;
  name: string;
}

export interface OrganizationsFiltersProps {
  totalCount: number;
  totalPages?: number;
  search: string;
  onSearchChange: (v: string) => void;
  showFilters: boolean;
  onShowFiltersToggle: () => void;
  hasActiveFilters: boolean;
  regionFilter: string;
  onRegionChange: (id: string) => void;
  okvedFilter: string;
  onOkvedChange: (code: string) => void;
  minRevenue: number;
  maxRevenue: number;
  onRevenueChange: ([lo, hi]: [number, number]) => void;
  minAge: number;
  maxAge: number;
  onAgeChange: ([lo, hi]: [number, number]) => void;
  hasGeoFilter: boolean;
  onHasGeoChange: (v: boolean) => void;
  hasDirectorFilter: boolean;
  onHasDirectorChange: (v: boolean) => void;
  hasNameFilter: boolean;
  onHasNameChange: (v: boolean) => void;
  onApplyPreset: (type: string) => void;
  onResetFilters: () => void;
  regionsList: RegionOption[];
  presetInfoRef: React.RefObject<HTMLDivElement | null>;
  presetInfoOpen: boolean;
  onPresetInfoOpenChange: (v: boolean) => void;
}

export function OrganizationsFilters({
  totalCount,
  search,
  onSearchChange,
  showFilters,
  onShowFiltersToggle,
  hasActiveFilters,
  regionFilter,
  onRegionChange,
  okvedFilter,
  onOkvedChange,
  minRevenue,
  maxRevenue,
  onRevenueChange,
  minAge,
  maxAge,
  onAgeChange,
  hasGeoFilter,
  onHasGeoChange,
  hasDirectorFilter,
  onHasDirectorChange,
  hasNameFilter,
  onHasNameChange,
  onApplyPreset,
  onResetFilters,
  regionsList,
  totalPages = 0,
  presetInfoRef,
  presetInfoOpen,
  onPresetInfoOpenChange
}: OrganizationsFiltersProps) {
  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border-2 border-gray-200 space-y-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Организации</h1>
          <p className="text-gray-500 text-sm font-medium">
            Найдено {totalCount.toLocaleString()} уникальных записей
            {totalPages > 0 && (
              <span className="text-gray-400"> · {totalPages} {totalPages === 1 ? 'страница' : totalPages < 5 ? 'страницы' : 'страниц'}</span>
            )}
          </p>
        </div>
        <div className="flex flex-col sm:flex-row w-full md:w-auto gap-3">
          <div className="relative w-full sm:w-80">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" aria-hidden />
            <input
              type="text"
              placeholder="Поиск по ИНН, ОГРН или названию..."
              className="w-full pl-10 pr-4 py-2.5 border-2 border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-gray-400 text-sm font-medium"
              value={search}
              onChange={(e) => onSearchChange(e.target.value)}
            />
          </div>
          <button
            onClick={onShowFiltersToggle}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-bold transition-all ${showFilters || hasActiveFilters ? 'bg-gray-100 border-2 border-gray-300 text-gray-800' : 'bg-white border-2 border-gray-200 text-gray-700 hover:bg-gray-50 shadow-sm'}`}
          >
            <Filter className="w-4 h-4" />
            Фильтры {hasActiveFilters && '(Активны)'}
          </button>
        </div>
      </div>

      {showFilters && (
        <div className="pt-4 border-t border-gray-100 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div>
              <label className="block text-[10px] font-black text-gray-400 mb-1.5 uppercase tracking-widest">Регион</label>
              <RegionCombobox
                value={regionFilter}
                onChange={onRegionChange}
                options={regionsList}
                placeholder="Все регионы"
              />
            </div>
            <div>
              <label className="block text-[10px] font-black text-gray-400 mb-1.5 uppercase tracking-widest">ОКВЭД</label>
              <OkvedCombobox
                value={okvedFilter}
                onChange={onOkvedChange}
                placeholder="Все виды деятельности"
              />
            </div>
            <div className="sm:col-span-2 lg:col-span-1">
              <DualRangeSlider
                min={0}
                max={REVENUE_MAX}
                step={100}
                value={[minRevenue, maxRevenue]}
                onChange={onRevenueChange}
                label="Выручка (тыс. ₽)"
                formatValue={(v) => v.toLocaleString('ru-RU')}
              />
            </div>
            <div>
              <DualRangeSlider
                min={0}
                max={AGE_MAX}
                step={1}
                value={[minAge, maxAge]}
                onChange={onAgeChange}
                label="Возраст (лет)"
              />
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-6">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={hasGeoFilter}
                onChange={(e) => onHasGeoChange(e.target.checked)}
                className="rounded border-2 border-gray-300 accent-black w-4 h-4"
              />
              <span className="text-sm font-bold text-gray-700">С геоданными</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={hasDirectorFilter}
                onChange={(e) => onHasDirectorChange(e.target.checked)}
                className="rounded border-2 border-gray-300 accent-black w-4 h-4"
              />
              <span className="text-sm font-bold text-gray-700">С директором</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={hasNameFilter}
                onChange={(e) => onHasNameChange(e.target.checked)}
                className="rounded border-2 border-gray-300 accent-black w-4 h-4"
              />
              <span className="text-sm font-bold text-gray-700">С названием из ЕГРЮЛ</span>
            </label>
            <div className="flex flex-wrap items-center gap-3 ml-auto">
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => onApplyPreset('real_companies')}
                  className="px-3 py-1.5 bg-gray-100 text-gray-800 border border-gray-200 rounded-lg text-xs font-bold hover:bg-gray-200 transition-colors"
                >
                  Отсеять однодневки
                </button>
                <div
                  ref={presetInfoRef as React.RefObject<HTMLDivElement>}
                  className="relative"
                  onMouseEnter={() => onPresetInfoOpenChange(true)}
                  onMouseLeave={() => onPresetInfoOpenChange(false)}
                >
                  <button
                    type="button"
                    onClick={() => onPresetInfoOpenChange(!presetInfoOpen)}
                    className="p-1 rounded-lg text-gray-500 hover:text-gray-700 hover:bg-gray-100 transition-colors"
                    aria-label="Подсказка"
                  >
                    <Info className="w-4 h-4" />
                  </button>
                  {presetInfoOpen && typeof document !== 'undefined' && createPortal(
                    <PresetTooltipPortal anchorRef={presetInfoRef} onClose={() => onPresetInfoOpenChange(false)} />,
                    document.body
                  )}
                </div>
              </div>
              <button onClick={onResetFilters} className="px-3 py-1.5 text-xs font-black uppercase text-gray-400 hover:text-gray-700 transition-colors">
                Сбросить все
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
