"use client";

import { MapPin, Calendar, Banknote, Plus, Check, Loader2, ChevronLeft, ChevronRight } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { translateRegion } from '@/lib/regions';
import { abbreviateLegalForm } from '@/lib/companyName';
import { getOkvedName } from '@/lib/okved';
import type { CompanyMeta } from 'shared';
import { BatchSelectHeader } from './BatchSelectHeader';

interface SortIconProps {
  sortBy: string;
  sortOrder: string;
  field: string;
}

function SortIcon({ sortBy, sortOrder, field }: SortIconProps) {
  if (sortBy !== field) return <span className="text-gray-300 ml-1 inline-block w-3 h-3">⇅</span>;
  return <span className="text-gray-700 ml-1 inline-block text-xs font-bold">{sortOrder === 'ASC' ? '↑' : '↓'}</span>;
}

interface OrganizationsTableProps {
  data: CompanyMeta[];
  loading: boolean;
  page: number;
  pagination: { total: number; limit: number; totalPages: number };
  pageItems: { inn: string; name: string }[];
  batchInnSet: Set<string>;
  sortBy: string;
  sortOrder: string;
  formatCurrency: (val: number | undefined) => string;
  handleSort: (field: string) => void;
  goToPage: (updater: (p: number) => number) => void;
  toggleBatch: (inn: string, name: string, e: React.MouseEvent) => void;
  toggleBatchPage: (items: { inn: string; name: string }[], e?: React.SyntheticEvent) => void;
}

export function OrganizationsTable({
  data,
  loading,
  page,
  pagination,
  pageItems,
  batchInnSet,
  sortBy,
  sortOrder,
  formatCurrency,
  handleSort,
  goToPage,
  toggleBatch,
  toggleBatchPage
}: OrganizationsTableProps) {
  const router = useRouter();

  return (
    <div className="hidden lg:block overflow-x-auto">
      <table className="w-full text-left text-sm whitespace-nowrap table-fixed" style={{ minWidth: 720 }}>
        <colgroup>
          <col style={{ width: '36%' }} />
          <col style={{ width: '18%' }} />
          <col style={{ width: '12%' }} />
          <col style={{ width: '10%' }} />
          <col style={{ width: '8%' }} />
        </colgroup>
        <thead className="bg-gradient-to-r from-gray-100 to-gray-50 text-[10px] font-black uppercase tracking-widest text-gray-500 border-b-2 border-gray-200">
          <tr>
            <th
              className="px-6 py-4 cursor-pointer hover:bg-gray-100 transition-colors select-none"
              onClick={(e) => {
                e.stopPropagation();
                e.preventDefault();
                handleSort('name');
              }}
            >
              Название <SortIcon sortBy={sortBy} sortOrder={sortOrder} field="name" />
            </th>
            <th
              className="px-6 py-4 cursor-pointer hover:bg-gray-100 transition-colors select-none"
              onClick={(e) => {
                e.stopPropagation();
                e.preventDefault();
                handleSort('revenue');
              }}
            >
              Выручка <SortIcon sortBy={sortBy} sortOrder={sortOrder} field="revenue" />
            </th>
            <th
              className="px-6 py-4 cursor-pointer hover:bg-gray-100 transition-colors select-none"
              onClick={(e) => {
                e.stopPropagation();
                e.preventDefault();
                handleSort('age');
              }}
            >
              Возраст <SortIcon sortBy={sortBy} sortOrder={sortOrder} field="age" />
            </th>
            <th className="px-6 py-4 text-center">Гео</th>
            <th className="px-6 py-4 text-center w-20" onClick={(e) => e.stopPropagation()}>
              <BatchSelectHeader
                allPageInBatch={pageItems.length > 0 && pageItems.every((x) => batchInnSet.has(x.inn))}
                somePageInBatch={pageItems.some((x) => batchInnSet.has(x.inn))}
                pageItems={pageItems}
                toggleBatchPage={toggleBatchPage}
                variant="desktop"
              />
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100 text-gray-800">
          {loading ? (
            <tr>
              <td colSpan={5} className="px-6 py-16 text-center">
                <div className="flex items-center justify-center">
                  <Loader2 className="w-10 h-10 animate-spin text-gray-600" />
                </div>
              </td>
            </tr>
          ) : data.length === 0 ? (
            <tr>
              <td colSpan={5} className="px-6 py-12 text-center text-gray-500 font-medium">
                Организации не найдены.
              </td>
            </tr>
          ) : (
            data.map((row, i) => {
              const id = row.inn || row.ogrn || '';
              const inBatch = batchInnSet.has(id);
              return (
                <tr
                  key={id || i}
                  onClick={() => router.push(`/organizations/${id}`)}
                  className="hover:bg-gray-100 transition-colors cursor-pointer group"
                >
                  <td className="px-6 py-4 overflow-hidden">
                    <div className="flex flex-col min-w-0 gap-0.5">
                      <span className="font-bold text-gray-900 truncate" title={row.name}>
                        {abbreviateLegalForm(row.name) || (
                          <span className="text-gray-300 font-normal italic lowercase">Без названия</span>
                        )}
                      </span>
                      <div className="flex items-center gap-3 flex-wrap">
                        <span
                          className={`text-[9px] font-black uppercase tracking-tighter ${row.status === 'Действующая' ? 'text-gray-700' : 'text-gray-500'}`}
                        >
                          {row.status || 'Неизвестно'}
                        </span>
                        <span className="font-mono text-[10px] font-bold text-gray-500">
                          ИНН: {row.inn || '—'}
                          {row.region && (
                            <span className="text-gray-400 font-normal"> · {translateRegion(row.region)}</span>
                          )}
                          {row.okved && (() => {
                            const name = getOkvedName(row.okved);
                            return (
                              <span className="text-gray-400 font-normal" title={name ?? row.okved}>
                                {' · '}{row.okved}{name ? ` — ${name}` : ''}
                              </span>
                            );
                          })()}
                        </span>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-gray-700">
                      <Banknote className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                      <span className="truncate">{formatCurrency(row.revenue)}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-gray-600">
                      <Calendar className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                      {row.age !== undefined ? `${row.age} л.` : '-'}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    {row.lon && row.lat ? (
                      <MapPin className="w-4 h-4 text-gray-600 inline-block opacity-60" />
                    ) : (
                      <span className="text-gray-300">-</span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-center" onClick={(e) => e.stopPropagation()}>
                    <button
                      onClick={(e) => toggleBatch(id, row.name || '', e)}
                      className={`p-2 rounded-2xl transition-all duration-200 ${inBatch ? 'bg-gray-800 text-white hover:bg-gray-900' : 'bg-gray-100 text-gray-500 hover:bg-gray-200 hover:text-gray-900'}`}
                      title={inBatch ? 'Убрать из батча' : 'Добавить в батч'}
                    >
                      {inBatch ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                    </button>
                  </td>
                </tr>
              );
            })
          )}
        </tbody>
      </table>
      <div className="px-6 py-4 border-t-2 border-gray-300 flex items-center justify-between bg-gray-50/50">
        <span className="text-[10px] font-black uppercase text-gray-400 tracking-widest">
          Страница {page} из {pagination.totalPages || 1}
        </span>
        <div className="flex gap-2">
          <button
            disabled={page === 1}
            onClick={(e) => {
              e.stopPropagation();
              goToPage((p) => Math.max(1, p - 1));
            }}
            className="p-2 border-2 border-gray-300 bg-white rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            disabled={page >= pagination.totalPages}
            onClick={(e) => {
              e.stopPropagation();
              goToPage((p) => p + 1);
            }}
            className="p-2 border-2 border-gray-300 bg-white rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
