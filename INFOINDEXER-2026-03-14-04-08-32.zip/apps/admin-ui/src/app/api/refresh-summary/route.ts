import { NextResponse } from 'next/server';
import { clickhouseClient, redisClient } from 'shared';
import { checkAuth, UNAUTHORIZED_RESPONSE } from '@/lib/auth';

export const dynamic = 'force-dynamic';
const REDIS_KEY = 'sync:status:refresh_summary';

/**
 * POST /api/refresh-summary — запускает задачу обновления кэша (асинхронно).
 * Возвращает сразу. Статус — через GET /api/sync/status (поле refresh_summary).
 */
export async function POST(request: Request) {
  if (!checkAuth(request)) {
    return NextResponse.json(UNAUTHORIZED_RESPONSE.json, { status: UNAUTHORIZED_RESPONSE.status });
  }

  try {
    const state = await redisClient.hgetall(REDIS_KEY);
    if (state?.status === 'running') {
      return NextResponse.json({ error: 'Обновление кэша уже выполняется' }, { status: 400 });
    }

    await redisClient.hset(REDIS_KEY, { status: 'running', percentage: '0', message: 'Запуск...' });

    // Фоновый запуск — не блокируем ответ
    (async () => {
      try {
        const { refreshFinancialSummary } = await import('shared');
        const reportProgress = async (stage: string, percentage: number, message: string) => {
          await redisClient.hset(REDIS_KEY, { status: 'running', percentage: String(percentage), message });
        };
        const { rows, elapsedMs } = await refreshFinancialSummary(clickhouseClient, { reportProgress });
        await redisClient.hset(REDIS_KEY, {
          status: 'completed',
          percentage: '100',
          rows: String(rows),
          elapsedMs: String(elapsedMs),
          completed_at: new Date().toISOString()
        });
      } catch (error) {
        console.error('Refresh summary error:', error);
        const message = error instanceof Error ? error.message : 'Unknown error';
        await redisClient.hset(REDIS_KEY, { status: 'error', error: message });
      }
    })();

    return NextResponse.json({ success: true });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
