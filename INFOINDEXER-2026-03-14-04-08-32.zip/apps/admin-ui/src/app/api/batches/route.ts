import { NextResponse } from 'next/server';
import { redisClient } from 'shared';
import { checkAuth, UNAUTHORIZED_RESPONSE } from '@/lib/auth';

const BATCH_LIMIT = 50;
const BATCH_TTL_DAYS = 7;
const BATCH_TTL_SEC = BATCH_TTL_DAYS * 24 * 60 * 60;

interface BatchInnItem {
  inn: string;
  name: string;
}

function generateBatchId(): string {
  return `b_${Date.now()}_${Math.random().toString(36).slice(2, 11)}`;
}

/** GET /api/batches — список батчей (история) с пагинацией */
export async function GET(request: Request) {
  if (!checkAuth(request)) {
    return NextResponse.json(UNAUTHORIZED_RESPONSE.json, { status: UNAUTHORIZED_RESPONSE.status });
  }

  try {
    const { searchParams } = new URL(request.url);
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(50, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const offset = (page - 1) * limit;

    const batchIds = await redisClient.zrevrange('batch:list', offset, offset + limit - 1);

    const items: Array<{
      batchId: string;
      createdAt: number;
      status: string;
      totalCount: number;
      completedCount: number;
      innsCount: number;
    }> = [];

    const pipeline = redisClient.pipeline();
    for (const batchId of batchIds) {
      pipeline.hgetall(`batch:${batchId}`);
    }
    const batchMetasRaw = await pipeline.exec();
    const batchMetas: [Error | null, unknown][] = batchMetasRaw ?? [];

    const innsToFetch: { batchId: string; batchIdx: number; inns: BatchInnItem[] }[] = [];

    for (let i = 0; i < batchIds.length; i++) {
      const res = batchMetas[i];
      const meta = res && res[0] === null ? (res[1] as Record<string, string>) : null;
      if (!meta || !meta.status) continue;

      const inns = meta.inns ? (JSON.parse(meta.inns) as BatchInnItem[]) : [];
      const completedCount = parseInt(meta.completedCount || '0', 10);
      const batchId = batchIds[i] as string;

      const itemIdx = items.length;
      if ((meta.status === 'running' || meta.status === 'completed') && inns.length > 0) {
        innsToFetch.push({ batchId, batchIdx: itemIdx, inns });
      }

      items.push({
        batchId: batchIds[i] as string,
        createdAt: parseInt(meta.createdAt || '0', 10),
        status: meta.status,
        totalCount: inns.length,
        completedCount,
        innsCount: inns.length
      });
    }

    if (innsToFetch.length > 0) {
      const statusPipeline = redisClient.pipeline();
      for (const { batchId, inns } of innsToFetch) {
        for (const { inn } of inns) {
          statusPipeline.hget(`batch:${batchId}:inn_status`, inn);
        }
      }
      const batchStatusResults = await statusPipeline.exec();
      const fallbackInns: { batchIdx: number; innIdx: number; inn: string }[] = [];
      if (batchStatusResults) {
        let idx = 0;
        for (const { batchIdx, inns } of innsToFetch) {
          for (let j = 0; j < inns.length; j++) {
            const r = batchStatusResults[idx++];
            const st = r && r[0] === null ? (r[1] as string) : null;
            if (st === null) fallbackInns.push({ batchIdx, innIdx: j, inn: inns[j].inn });
          }
        }
      }
      const fallbackPipeline = redisClient.pipeline();
      const fallbackKeys = Array.from(new Set(fallbackInns.map((f) => f.inn)));
      for (const inn of fallbackKeys) {
        fallbackPipeline.hget(`contacts:status:${inn}`, 'status');
      }
      const fallbackResults = fallbackKeys.length > 0 ? await fallbackPipeline.exec() : null;
      const fallbackMap = new Map<string, string>();
      if (fallbackResults) {
        fallbackKeys.forEach((inn, i) => {
          const r = fallbackResults[i];
          const st = r && r[0] === null ? (r[1] as string) : null;
          if (st) fallbackMap.set(inn, st);
        });
      }
      let idx = 0;
      const toComplete: string[] = [];
      for (const { batchId, batchIdx, inns } of innsToFetch) {
        let done = 0;
        for (let j = 0; j < inns.length; j++) {
          const r = batchStatusResults?.[idx++];
          let st = r && r[0] === null ? (r[1] as string) : null;
          if (st === null) st = fallbackMap.get(inns[j].inn) ?? null;
          if (st === 'completed' || st === 'error') done++;
        }
        if (items[batchIdx]) {
          items[batchIdx].completedCount = done;
          if (done === inns.length && items[batchIdx].status === 'running') {
            toComplete.push(batchId);
            items[batchIdx].status = 'completed';
          }
        }
      }
      if (toComplete.length > 0) {
        const updatePipeline = redisClient.pipeline();
        for (const bid of toComplete) {
          updatePipeline.hset(`batch:${bid}`, 'status', 'completed');
        }
        await updatePipeline.exec();
      }
    }

    const total = await redisClient.zcard('batch:list');

    return NextResponse.json({
      items,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit)
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

/** POST /api/batches — создать батч, вернуть batchId */
export async function POST(request: Request) {
  if (!checkAuth(request)) {
    return NextResponse.json(UNAUTHORIZED_RESPONSE.json, { status: UNAUTHORIZED_RESPONSE.status });
  }

  try {
    const body = (await request.json()) as { inns?: BatchInnItem[] };
    const rawInns = Array.isArray(body?.inns) ? body.inns : [];

    if (rawInns.length === 0) {
      return NextResponse.json(
        { error: 'inns array is required and must not be empty' },
        { status: 400 }
      );
    }

    if (rawInns.length > BATCH_LIMIT) {
      return NextResponse.json(
        { error: `Maximum ${BATCH_LIMIT} organizations per batch` },
        { status: 400 }
      );
    }

    const inns: BatchInnItem[] = rawInns.filter(
      (x): x is BatchInnItem =>
        x && typeof x.inn === 'string' && x.inn.length > 0
    ).map(x => ({ inn: x.inn, name: typeof x.name === 'string' ? x.name : '' }));

    if (inns.length === 0) {
      return NextResponse.json({ error: 'No valid inns' }, { status: 400 });
    }

    const batchId = generateBatchId();
    const now = Date.now();

    await redisClient
      .multi()
      .hset(`batch:${batchId}`, {
        status: 'pending',
        createdAt: now.toString(),
        inns: JSON.stringify(inns),
        totalCount: inns.length.toString(),
        completedCount: '0'
      })
      .zadd('batch:list', now, batchId)
      .expire(`batch:${batchId}`, BATCH_TTL_SEC)
      .exec();

    return NextResponse.json({ batchId });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
