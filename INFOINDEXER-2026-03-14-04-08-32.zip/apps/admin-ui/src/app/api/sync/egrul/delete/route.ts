import { NextResponse } from 'next/server';
import { redisClient, clickhouseClient } from 'shared';
import { checkAuth, UNAUTHORIZED_RESPONSE } from '@/lib/auth';

/** POST /api/sync/egrul/delete — полная очистка реестра ЕГРЮЛ (companies_meta) */
export async function POST(request: Request) {
  if (!checkAuth(request)) {
    return NextResponse.json(UNAUTHORIZED_RESPONSE.json, {
      status: UNAUTHORIZED_RESPONSE.status
    });
  }

  try {
    const state = await redisClient.hgetall('sync:status:egrul');
    if (state?.status === 'running') {
      return NextResponse.json(
        { error: 'Синхронизация ЕГРЮЛ в процессе. Дождитесь завершения.' },
        { status: 400 }
      );
    }

    await clickhouseClient.command({ query: 'TRUNCATE TABLE companies_meta' });
    await redisClient.del('sync:status:egrul');

    return NextResponse.json({ success: true });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
