"use client";

import { useCallback, useEffect, useState } from "react";
import { ChevronRight, ChevronLeft } from "lucide-react";
import { getAuthHeaders } from "@/lib/api";

interface BatchHistoryItem {
  batchId: string;
  createdAt: number;
  status: string;
  totalCount: number;
  completedCount: number;
  innsCount: number;
}

interface BatchHistoryTableProps {
  onGoToArchive: (batchId: string) => void;
  /** При изменении вызывает перезагрузку истории (для отображения нового батча после отправки) */
  refreshTrigger?: number;
}

const PAGE_SIZE = 20;

export function BatchHistoryTable({
  onGoToArchive,
  refreshTrigger = 0
}: BatchHistoryTableProps) {
  const [items, setItems] = useState<BatchHistoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);

  const loadHistory = useCallback(async (pageNum: number, silent = false) => {
    if (!silent) setLoading(true);
    try {
      const res = await fetch(
        `/api/batches?page=${pageNum}&limit=${PAGE_SIZE}`,
        { headers: getAuthHeaders() }
      );
      const json = (await res.json()) as {
        items?: BatchHistoryItem[];
        total?: number;
        totalPages?: number;
        error?: string;
      };
      if (res.ok && Array.isArray(json.items)) {
        setItems(json.items);
        setTotal(json.total ?? 0);
        setTotalPages(json.totalPages ?? 1);
      }
    } catch {
      setItems([]);
    } finally {
      if (!silent) setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadHistory(page);
  }, [loadHistory, page, refreshTrigger]);

  // Периодическое обновление, когда есть батчи «В работе» — без поллинга список не обновляется сам
  const hasRunning = items.some((i) => i.status === "running");
  useEffect(() => {
    if (!hasRunning) return;
    const interval = setInterval(() => loadHistory(page, true), 2000);
    return () => clearInterval(interval);
  }, [hasRunning, loadHistory, page]);

  const statusLabel = (status: string) => {
    if (status === "completed") return "Завершено";
    if (status === "running") return "В работе";
    if (status === "error") return "Ошибка";
    if (status === "pending") return "Ожидание";
    return status;
  };

  const statusClass = (status: string) => {
    if (status === "completed") return "bg-gray-200 text-gray-800";
    if (status === "running") return "bg-gray-100 text-gray-700";
    if (status === "error") return "bg-gray-100 text-gray-700";
    return "bg-gray-100 text-gray-600";
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <p className="text-gray-500">Загрузка истории...</p>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 gap-4">
        <p className="text-gray-500 text-center">
          Нет завершённых батчей
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-2xl lg:rounded-3xl border border-gray-200 bg-white shadow-lg overflow-hidden">
      {/* Мобильный карточный layout */}
      <div className="lg:hidden p-4 space-y-4">
        {items.map(item => {
          const pct =
            item.totalCount > 0
              ? Math.round((item.completedCount / item.totalCount) * 100)
              : 0;
          return (
            <div
              key={item.batchId}
              className="p-6 rounded-2xl bg-gradient-to-br from-white via-gray-50/50 to-gray-100/50 border border-gray-200 shadow-md hover:shadow-xl hover:border-gray-300 transition-all duration-200"
            >
              <div className="flex flex-col gap-4">
                <div className="flex flex-col gap-1">
                  <span className="font-mono text-sm font-bold text-gray-900 truncate">
                    {item.batchId}
                  </span>
                  <span className="text-xs text-gray-500">
                    {new Date(item.createdAt).toLocaleString("ru-RU")}
                  </span>
                </div>
                <div className="flex flex-col gap-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">
                      Прогресс
                    </span>
                    <span className="text-xs font-bold text-gray-600">{pct}%</span>
                  </div>
                  <div className="h-2.5 w-full bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gray-800 transition-all duration-300"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
                <div className="flex items-center justify-between gap-4 pt-2">
                  <span
                    className={`inline-block px-3 py-1.5 rounded-xl text-xs font-bold ${statusClass(
                      item.status
                    )}`}
                  >
                    {statusLabel(item.status)}
                  </span>
                  <button
                    onClick={() => onGoToArchive(item.batchId)}
                    className="flex items-center justify-center gap-2 min-h-12 px-4 rounded-2xl bg-gray-900 text-white hover:bg-gray-800 transition-all duration-200 text-sm font-bold"
                  >
                    Перейти
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Десктопная таблица */}
      <div className="hidden lg:block overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="border-b-2 border-gray-200 bg-gradient-to-r from-gray-100 to-gray-50">
              <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-gray-500">
                ID операции
              </th>
              <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-gray-500">
                Дата
              </th>
              <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-gray-500">
                Прогресс
              </th>
              <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-gray-500">
                Статус
              </th>
              <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-gray-500 w-28">
                Действие
              </th>
            </tr>
          </thead>
          <tbody>
            {items.map(item => {
              const pct =
                item.totalCount > 0
                  ? Math.round((item.completedCount / item.totalCount) * 100)
                  : 0;
              return (
                <tr
                  key={item.batchId}
                  className="border-b border-gray-100 hover:bg-gray-50 transition-all duration-200"
                >
                  <td className="px-6 py-4">
                    <span className="font-mono text-sm font-bold text-gray-800">
                      {item.batchId}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">
                    {new Date(item.createdAt).toLocaleString("ru-RU")}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 w-32">
                      <div className="h-2.5 flex-1 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gray-800 transition-all duration-300"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                      <span className="text-xs font-bold text-gray-600 shrink-0">
                        {pct}%
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`inline-block px-3 py-1.5 rounded-xl text-xs font-bold ${statusClass(
                        item.status
                      )}`}
                    >
                      {statusLabel(item.status)}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => onGoToArchive(item.batchId)}
                      className="flex items-center gap-2 px-4 py-3 rounded-2xl bg-gray-100 text-gray-700 hover:bg-gray-800 hover:text-white transition-all duration-200 text-sm font-bold"
                    >
                      Перейти
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between gap-4 px-4 py-3 border-t border-gray-200 bg-gray-50">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page <= 1}
            className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold text-gray-700 bg-white border border-gray-200 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
          >
            <ChevronLeft className="w-4 h-4" />
            Назад
          </button>
          <span className="text-sm text-gray-600">
            Страница <strong>{page}</strong> из <strong>{totalPages}</strong>
            {total > 0 && (
              <span className="ml-2 text-gray-500">
                ({total} всего)
              </span>
            )}
          </span>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page >= totalPages}
            className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold text-gray-700 bg-white border border-gray-200 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
          >
            Вперёд
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
}
