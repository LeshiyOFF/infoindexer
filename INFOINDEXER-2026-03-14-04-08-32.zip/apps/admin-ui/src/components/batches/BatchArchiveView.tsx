"use client";

import { useCallback, useEffect, useState } from "react";
import { ArrowLeft, DownloadCloud, RotateCcw, Menu, X, Filter } from "lucide-react";
import { getAuthHeaders } from "@/lib/api";
import { abbreviateLegalForm } from "@/lib/companyName";
import { BatchResultsFeed } from "./BatchResultsFeed";

interface BatchInnItem {
  inn: string;
  name: string;
}

interface BatchArchiveViewProps {
  batchId: string;
  onBackToHistory: () => void;
}

export function BatchArchiveView({
  batchId,
  onBackToHistory
}: BatchArchiveViewProps) {
  const [meta, setMeta] = useState<{
    inns: BatchInnItem[];
    status: string;
    totalCount: number;
    completedCount: number;
  } | null>(null);
  const [results, setResults] = useState<
    Record<string, { status: string; data?: unknown; error?: string }>
  | null>(null);
  const [loading, setLoading] = useState(true);
  const [rerunning, setRerunning] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [leftDrawerOpen, setLeftDrawerOpen] = useState(false);
  const [selectedCompanyInn, setSelectedCompanyInn] = useState<string | null>(null);

  const loadData = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const [metaRes, resultsRes] = await Promise.all([
        fetch(`/api/batches/${batchId}`, { headers: getAuthHeaders() }),
        fetch(`/api/batches/${batchId}/results`, {
          headers: getAuthHeaders()
        })
      ]);

      const metaJson = (await metaRes.json()) as {
        batchId?: string;
        status?: string;
        inns?: BatchInnItem[];
        totalCount?: number;
        completedCount?: number;
        error?: string;
      };
      const resultsJson = (await resultsRes.json()) as {
        results?: Record<string, { status: string; data?: unknown; error?: string }>;
        error?: string;
      };

      if (metaRes.ok && metaJson.inns) {
        setMeta({
          inns: metaJson.inns,
          status: metaJson.status ?? "unknown",
          totalCount: metaJson.totalCount ?? 0,
          completedCount: metaJson.completedCount ?? 0
        });
      }
      if (resultsRes.ok && resultsJson.results) {
        setResults(resultsJson.results);
      }
    } catch {
      if (!silent) {
        setMeta(null);
        setResults(null);
      }
    } finally {
      if (!silent) setLoading(false);
    }
  }, [batchId]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Обновление в реальном времени при статусе «В работе»
  const isRunning = meta?.status === "running";
  useEffect(() => {
    if (!isRunning) return;
    const interval = setInterval(() => loadData(true), 3000);
    return () => clearInterval(interval);
  }, [isRunning, loadData]);

  const handleRerun = useCallback(async () => {
    if (!meta?.inns?.length) return;
    setRerunning(true);
    try {
      const createRes = await fetch("/api/batches", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...getAuthHeaders()
        },
        body: JSON.stringify({ inns: meta.inns })
      });
      const createJson = (await createRes.json()) as {
        batchId?: string;
        error?: string;
      };

      if (!createRes.ok) {
        alert(createJson.error ?? "Ошибка создания батча");
        return;
      }

      const newBatchId = createJson.batchId;
      if (!newBatchId) {
        alert("Не получен ID батча");
        return;
      }

      const startRes = await fetch("/api/organizations/batch-contacts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...getAuthHeaders()
        },
        body: JSON.stringify({ batchId: newBatchId })
      });

      if (!startRes.ok) {
        const startJson = (await startRes.json()) as { error?: string };
        alert(startJson.error ?? "Ошибка запуска");
        return;
      }

      onBackToHistory();
      window.location.href = "/batches";
    } catch (err) {
      alert(err instanceof Error ? err.message : "Ошибка сети");
    } finally {
      setRerunning(false);
    }
  }, [meta?.inns, onBackToHistory]);

  const handleExport = useCallback(async () => {
    setExporting(true);
    try {
      const res = await fetch(
        `/api/batches/${batchId}/export?format=xlsx`,
        { headers: getAuthHeaders() }
      );
      if (!res.ok) {
        const json = (await res.json()) as { error?: string };
        alert(json.error ?? "Ошибка экспорта");
        return;
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `batch-${batchId}.xlsx`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      alert(err instanceof Error ? err.message : "Ошибка экспорта");
    } finally {
      setExporting(false);
    }
  }, [batchId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <p className="text-gray-500">Загрузка архива...</p>
      </div>
    );
  }

  if (!meta) {
    return (
      <div className="flex flex-col items-center justify-center py-16 gap-4">
        <p className="text-gray-500 text-center">
          Батч не найден
        </p>
        <button
          onClick={onBackToHistory}
          className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-gray-100 text-gray-700 hover:bg-gray-200 transition-all duration-200"
        >
          <ArrowLeft className="w-4 h-4" />
          Вернуться к истории
        </button>
      </div>
    );
  }

  const companiesPanel = (
    <div className="flex flex-col gap-4 p-6 rounded-2xl bg-white border border-gray-200 shadow-sm overflow-hidden">
      <h2 className="text-sm font-bold uppercase tracking-wider text-gray-600">
        Организации этой очереди
      </h2>
      {selectedCompanyInn && (
        <button
          onClick={() => setSelectedCompanyInn(null)}
          className="text-xs font-bold text-gray-600 hover:text-gray-900 self-start"
        >
          Показать все
        </button>
      )}
      <div className="flex-1 min-h-0 overflow-auto space-y-2">
        {meta.inns.map(b => (
          <button
            key={b.inn}
            type="button"
            onClick={() => setSelectedCompanyInn(prev => (prev === b.inn ? null : b.inn))}
            className={`w-full text-left p-3 rounded-xl border transition-all duration-200 flex items-center justify-between gap-2 ${
              selectedCompanyInn === b.inn
                ? "bg-gray-900 text-white border-gray-900"
                : "bg-gray-50 border-gray-200 hover:bg-gray-100 hover:border-gray-300"
            }`}
          >
            <span className="truncate text-sm font-bold flex-1 min-w-0" title={b.name}>
              {abbreviateLegalForm(b.name) || b.name}
            </span>
            {selectedCompanyInn === b.inn && (
              <Filter className="w-4 h-4 shrink-0" aria-label="Фильтр активен" />
            )}
          </button>
        ))}
      </div>
    </div>
  );

  return (
    <div className="flex flex-col flex-1 min-h-0">
      {leftDrawerOpen && (
        <>
          <div
            className="fixed left-0 top-14 right-0 bottom-0 bg-black/40 z-50 lg:hidden backdrop-blur-sm"
            onClick={() => setLeftDrawerOpen(false)}
            aria-hidden="true"
          />
          <div className="fixed left-0 top-14 bottom-0 w-[min(320px,85vw)] z-50 lg:hidden bg-white border-r border-gray-200 shadow-xl overflow-auto">
            <div className="p-4 flex items-center justify-between border-b border-gray-200">
              <h2 className="text-sm font-bold uppercase text-gray-600">
                Компании
              </h2>
              <button
                onClick={() => setLeftDrawerOpen(false)}
                className="p-2 rounded-xl hover:bg-gray-100 text-gray-500 hover:text-gray-900 transition-all duration-200"
                aria-label="Закрыть"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4">{companiesPanel}</div>
          </div>
        </>
      )}
      <header className="shrink-0 py-4 border-b border-gray-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-2 sm:gap-4 min-w-0 flex-1 flex-wrap">
          <button
            onClick={() => setLeftDrawerOpen(true)}
            className="lg:hidden flex items-center justify-center p-2 rounded-xl bg-gray-100 text-gray-600 hover:bg-gray-200 hover:text-gray-900 transition-all duration-200 shrink-0"
            aria-label="Открыть список компаний"
          >
            <Menu className="w-5 h-5" />
          </button>
          <button
            onClick={onBackToHistory}
            className="flex items-center gap-2 px-3 sm:px-4 py-2 rounded-2xl bg-gray-100 text-gray-700 hover:bg-gray-200 transition-all duration-200 shrink-0 text-sm"
          >
            <ArrowLeft className="w-4 h-4 shrink-0" />
            <span className="hidden xs:inline sm:inline">Вернуться к истории</span>
          </button>
          <span className="text-base sm:text-lg font-bold text-gray-900 truncate min-w-0">
            Архив: <span className="font-mono text-gray-700">{batchId}</span>
          </span>
        </div>
        <div className="flex flex-wrap sm:flex-nowrap items-center gap-2 sm:gap-3 shrink-0">
          <button
            onClick={handleRerun}
            disabled={rerunning}
            className="flex items-center justify-center gap-2 px-3 sm:px-4 py-2 rounded-2xl bg-black text-white font-bold text-xs sm:text-sm hover:bg-gray-800 disabled:opacity-50 transition-all duration-200"
          >
            <RotateCcw className="w-4 h-4 shrink-0" />
            {rerunning ? "Запуск..." : "Повторить запуск"}
          </button>
          <button
            onClick={handleExport}
            disabled={exporting}
            className="flex items-center justify-center gap-2 px-3 sm:px-4 py-2 rounded-2xl border-2 border-gray-300 text-gray-700 hover:bg-gray-100 font-bold text-xs sm:text-sm disabled:opacity-50 transition-all duration-200"
          >
            <DownloadCloud className="w-4 h-4 shrink-0" />
            {exporting ? "Экспорт..." : "Экспортировать отчёт"}
          </button>
        </div>
      </header>

      <div className="flex flex-col lg:flex-row flex-1 gap-6 min-h-0 overflow-hidden pt-6">
        <div className="hidden lg:flex lg:w-1/3 flex-col gap-6 min-h-0 shrink-0">
          <div className="flex flex-col gap-4 p-6 rounded-2xl bg-white border border-gray-200 shadow-sm overflow-hidden">
            <h2 className="text-sm font-bold uppercase tracking-wider text-gray-600">
              Организации этой очереди
            </h2>
            <div className="flex-1 min-h-0 overflow-auto space-y-2">
              {meta.inns.map(b => (
                <div
                  key={b.inn}
                  className={`p-3 rounded-xl border transition-all duration-200 cursor-pointer hover:border-gray-400 flex items-center justify-between gap-2 ${
                    selectedCompanyInn === b.inn
                      ? "bg-gray-200 border-gray-400"
                      : "bg-gray-50 border-gray-200"
                  }`}
                  onClick={() => setSelectedCompanyInn(prev => (prev === b.inn ? null : b.inn))}
                  role="button"
                  tabIndex={0}
                  onKeyDown={e => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      setSelectedCompanyInn(prev => (prev === b.inn ? null : b.inn));
                    }
                  }}
                >
                  <span className="truncate text-sm font-bold text-gray-900 flex-1 min-w-0" title={b.name}>
                    {abbreviateLegalForm(b.name) || b.name}
                  </span>
                  {selectedCompanyInn === b.inn && (
                    <Filter className="w-4 h-4 shrink-0 text-gray-700" aria-label="Фильтр активен" />
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        <BatchResultsFeed
          isArchive={true}
          batchId={batchId}
          archiveResults={results}
          archiveInns={meta.inns}
          selectedCompanyInn={selectedCompanyInn}
        />
      </div>
    </div>
  );
}
