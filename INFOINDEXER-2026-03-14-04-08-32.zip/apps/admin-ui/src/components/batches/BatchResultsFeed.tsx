"use client";

import { Phone, Mail, AlertCircle, Loader2, Clock } from "lucide-react";
import { useState, useMemo } from "react";
import Link from "next/link";
import { useBatch } from "@/contexts/BatchContext";
import { abbreviateLegalForm } from "@/lib/companyName";

type FilterType = "all" | "mail" | "phone";
type FilterRelevance = "all" | "relevant" | "not_relevant";

interface BatchResultsFeedProps {
  isArchive: boolean;
  batchId: string | null;
  archiveResults: Record<
    string,
    { status: string; data?: unknown; error?: string }
  > | null;
  /** Оригинальные имена компаний из meta.inns для корректного отображения при отсутствии data.name */
  archiveInns?: { inn: string; name: string }[];
  /** Фильтр по компании: показывать только контакты этой организации */
  selectedCompanyInn?: string | null;
}

interface ContactItem {
  inn: string;
  name: string;
  director?: string;
  val: string;
  type: string;
  source: string;
  kind: "phone" | "email";
}

function flattenContactsFromProgress(
  batchItems: { inn: string; name: string }[],
  batchProgress: Record<
    string,
    {
      status: string;
      data?: {
        emails?: { val: string; source: string; type?: string }[];
        phones?: { val: string; source: string; type?: string }[];
        director?: string;
        name?: string;
      };
    }
  >
): ContactItem[] {
  const items: ContactItem[] = [];
  for (const b of batchItems) {
    const p = batchProgress[b.inn];
    if (!p?.data) continue;
    (p.data.phones || []).forEach(ph => {
      items.push({
        inn: b.inn,
        name: p.data!.name || b.name,
        director: p.data!.director,
        val: ph.val,
        type: ph.type || "general",
        source: ph.source,
        kind: "phone"
      });
    });
    (p.data.emails || []).forEach(em => {
      items.push({
        inn: b.inn,
        name: p.data!.name || b.name,
        director: p.data!.director,
        val: em.val,
        type: em.type || "general",
        source: em.source,
        kind: "email"
      });
    });
  }
  return items;
}

function flattenContactsFromArchive(
  archiveResults: Record<
    string,
    { status: string; data?: { emails?: { val: string; source: string; type?: string }[]; phones?: { val: string; source: string; type?: string }[]; director?: string; name?: string }; error?: string }
  >,
  inns: { inn: string; name: string }[]
): ContactItem[] {
  const items: ContactItem[] = [];
  const nameMap = Object.fromEntries(inns.map(x => [x.inn, x.name]));
  for (const [inn, r] of Object.entries(archiveResults)) {
    const data = r.data;
    if (!data) continue;
    const name = data.name || nameMap[inn] || inn;
    (data.phones || []).forEach(ph => {
      items.push({
        inn,
        name,
        director: data.director,
        val: ph.val,
        type: ph.type || "general",
        source: ph.source,
        kind: "phone"
      });
    });
    (data.emails || []).forEach(em => {
      items.push({
        inn,
        name,
        director: data.director,
        val: em.val,
        type: em.type || "general",
        source: em.source,
        kind: "email"
      });
    });
  }
  return items;
}

export function BatchResultsFeed({
  isArchive,
  batchId,
  archiveResults,
  archiveInns,
  selectedCompanyInn = null
}: BatchResultsFeedProps) {
  const { batchItems, batchProgress } = useBatch();
  // batchId используется в key для сброса состояния при переключении архивного батча
  const [filterType, setFilterType] = useState<FilterType>("all");
  const [filterRelevance, setFilterRelevance] = useState<FilterRelevance>("all");

  const allContacts = useMemo(() => {
    if (isArchive && archiveResults) {
      const nameMap = archiveInns?.length
        ? Object.fromEntries(archiveInns.map(x => [x.inn, x.name]))
        : null;
      const inns = (archiveInns?.length ? archiveInns : Object.keys(archiveResults).map(inn => ({
        inn,
        name: (archiveResults[inn].data as { name?: string })?.name ?? nameMap?.[inn] ?? inn
      }))) as { inn: string; name: string }[];
      return flattenContactsFromArchive(
        archiveResults as Record<
          string,
          {
            status: string;
            data?: {
              emails?: { val: string; source: string; type?: string }[];
              phones?: { val: string; source: string; type?: string }[];
              director?: string;
              name?: string;
            };
            error?: string;
          }
        >,
        inns
      );
    }
    return flattenContactsFromProgress(batchItems, batchProgress);
  }, [isArchive, archiveResults, archiveInns, batchItems, batchProgress]);

  const filteredContacts = useMemo(() => {
    return allContacts.filter(c => {
      if (selectedCompanyInn && c.inn !== selectedCompanyInn) return false;
      if (filterType === "mail" && c.kind !== "email") return false;
      if (filterType === "phone" && c.kind !== "phone") return false;
      if (filterRelevance === "relevant" && c.type !== "direct") return false;
      if (filterRelevance === "not_relevant" && c.type === "direct") return false;
      return true;
    });
  }, [allContacts, filterType, filterRelevance, selectedCompanyInn]);

  const companiesWithoutResults = useMemo(() => {
    if (!isArchive || !archiveResults || !archiveInns?.length) return [];
    return archiveInns
      .filter(({ inn }) => {
        const r = archiveResults[inn];
        if (!r) return true;
        return !r.data || r.status === "error" || r.status === "running" || r.status === "idle";
      })
      .map(({ inn, name }) => {
        const r = archiveResults[inn];
        let statusLabel = "Нет данных";
        if (r?.status === "error") statusLabel = "Ошибка";
        else if (r?.status === "running") statusLabel = "В процессе";
        else if (r?.status === "idle") statusLabel = "Ожидание";
        return {
          inn,
          name: name || inn,
          status: r?.status ?? "idle",
          statusLabel,
          error: r?.error
        };
      });
  }, [isArchive, archiveResults, archiveInns]);

  return (
    <div
      key={batchId ?? "active"}
      className="flex-1 flex flex-col min-h-0 overflow-hidden"
    >
      <div className="flex flex-col gap-6 p-4 sm:p-6 rounded-2xl bg-white border border-gray-200 shadow-sm h-full overflow-hidden min-w-0">
        <h2 className="text-sm font-bold uppercase tracking-wider text-gray-600 shrink-0">
          Результаты
        </h2>

        <div className="flex flex-col sm:flex-row sm:flex-wrap items-stretch sm:items-center gap-3 sm:gap-x-4 sm:gap-y-3 shrink-0 min-w-0 overflow-x-auto max-w-full">
          <div className="flex flex-col sm:flex-row sm:items-center gap-2 min-w-0 shrink-0">
            <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest shrink-0">
              Тип:
            </span>
            <div className="flex flex-wrap gap-2 min-w-0">
              {(["all", "mail", "phone"] as const).map(t => (
                <button
                  key={t}
                  onClick={() => setFilterType(t)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all duration-200 shrink-0 ${
                    filterType === t
                      ? "bg-black text-white"
                      : "bg-gray-100 text-gray-600 hover:bg-gray-200 hover:text-gray-900"
                  }`}
                >
                  {t === "all" ? "Все" : t === "mail" ? "Почта" : "Телефоны"}
                </button>
              ))}
            </div>
          </div>
          <div className="flex flex-col sm:flex-row sm:items-center gap-2 min-w-0 shrink-0">
            <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest shrink-0">
              Релевантность:
            </span>
            <div className="flex flex-wrap gap-2 min-w-0">
              {(["all", "relevant", "not_relevant"] as const).map(r => (
                <button
                  key={r}
                  onClick={() => setFilterRelevance(r)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all duration-200 shrink-0 ${
                    filterRelevance === r
                      ? "bg-black text-white"
                      : "bg-gray-100 text-gray-600 hover:bg-gray-200 hover:text-gray-900"
                  }`}
                >
                  {r === "all"
                    ? "Все"
                    : r === "relevant"
                      ? "Релевантно"
                      : "Нерелевантно"}
                </button>
              ))}
            </div>
          </div>
        </div>

        {companiesWithoutResults.length > 0 && (
          <div className="shrink-0 rounded-xl border border-gray-200 bg-gray-50/50 p-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-800 mb-3">
              Организации в процессе обработки
            </h3>
            <div className="space-y-2">
              {companiesWithoutResults.map(({ inn, name, statusLabel, error }) => (
                <div
                  key={inn}
                  className="flex items-center justify-between gap-3 rounded-lg bg-white/80 p-3 border border-gray-100"
                >
                  <span className="truncate text-sm text-gray-900" title={name}>
                    {abbreviateLegalForm(name) || name}
                  </span>
                  <div className="flex items-center gap-2 shrink-0">
                    <span
                      className={`text-xs font-bold inline-flex items-center gap-1 ${
                        statusLabel === "Ошибка"
                          ? "text-red-600"
                          : statusLabel === "В процессе"
                            ? "text-gray-700"
                            : "text-gray-600"
                      }`}
                    >
                      {statusLabel === "Ошибка" && <AlertCircle className="w-3.5 h-3.5 shrink-0" />}
                      {statusLabel === "В процессе" && <Loader2 className="w-3.5 h-3.5 shrink-0 animate-spin" />}
                      {(statusLabel === "Ожидание" || statusLabel === "Нет данных") && <Clock className="w-3.5 h-3.5 shrink-0" />}
                      {statusLabel}
                    </span>
                    {error && (
                      <span className="text-[10px] text-red-600 truncate max-w-[120px]" title={error}>
                        {error}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex-1 min-h-0 overflow-auto space-y-3">
          {filteredContacts.length === 0 ? (
            <p className="text-gray-500 text-sm py-6 text-center">
              Нет контактов по выбранным фильтрам
            </p>
          ) : (
            filteredContacts.map((c, i) => (
              <div
                key={`${c.inn}-${c.val}-${i}`}
                className="p-4 rounded-xl bg-gray-50 border border-gray-200 hover:border-gray-300 transition-all duration-200"
              >
                <div className="flex items-center justify-between gap-2 mb-1">
                  <Link
                    href={`/organizations/${c.inn}`}
                    className="font-bold truncate text-gray-900 hover:text-gray-700 hover:underline transition-colors"
                  >
                    {abbreviateLegalForm(c.name)}
                  </Link>
                  <span
                    className={`text-[9px] font-black uppercase px-2 py-1 rounded-lg ${
                      c.type === "direct"
                        ? "bg-gray-200 text-gray-800"
                        : "bg-gray-100 text-gray-600"
                    }`}
                  >
                    {c.type === "direct" ? "Релевантно" : "Нерелевантно"}
                  </span>
                </div>
                {c.director && (
                  <p className="text-xs text-gray-500 mb-2">{c.director}</p>
                )}
                <a
                  href={
                    c.kind === "phone" ? `tel:${c.val}` : `mailto:${c.val}`
                  }
                  className="font-mono font-bold text-gray-700 hover:text-black truncate block transition-colors duration-200"
                >
                  {c.kind === "phone" ? (
                    <>
                      <Phone className="w-4 h-4 inline mr-1.5 align-middle" />
                      {c.val}
                    </>
                  ) : (
                    <>
                      <Mail className="w-4 h-4 inline mr-1.5 align-middle" />
                      {c.val}
                    </>
                  )}
                </a>
                <p className="text-[9px] text-gray-500 mt-1">{c.source}</p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
