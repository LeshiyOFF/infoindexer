"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode
} from 'react';
import { createPortal } from 'react-dom';
import { Plus } from 'lucide-react';
import { getAuthHeaders } from '@/lib/api';

const BATCH_STORAGE_KEY = 'org-batch-items';
const BATCH_NAV_BADGE_CLASS = 'batch-nav-badge-target';

export interface BatchItem {
  inn: string;
  name: string;
}

export interface BatchProgress {
  status: 'idle' | 'running' | 'completed' | 'error';
  stage?: string;
  data?: {
    emails: { val: string; source: string; type?: 'direct' | 'official' | 'general' | 'verified' }[];
    phones: { val: string; source: string; type?: 'direct' | 'official' | 'general' | 'verified' }[];
    director?: string;
    name?: string;
  };
  error?: string;
}

interface BatchContextValue {
  batchItems: BatchItem[];
  currentBatchId: string | null;
  batchProgress: Record<string, BatchProgress>;
  batchProcessing: boolean;
  overlayOpen: boolean;
  toggleBatch: (inn: string, name: string, e: React.MouseEvent) => void;
  toggleBatchPage: (items: { inn: string; name: string }[], e?: React.SyntheticEvent) => void;
  removeFromBatch: (inn: string, e: React.MouseEvent) => void;
  startBatch: () => Promise<void>;
  clearBatch: () => void;
  openOverlay: () => void;
  closeOverlay: () => void;
  setOverlayOpen: (open: boolean) => void;
}

const BatchContext = createContext<BatchContextValue | null>(null);

export function useBatch() {
  const ctx = useContext(BatchContext);
  if (!ctx) throw new Error('useBatch must be used within BatchProvider');
  return ctx;
}

export function BatchProvider({ children }: { children: ReactNode }) {
  const [batchItems, setBatchItems] = useState<BatchItem[]>([]);
  const [currentBatchId, setCurrentBatchId] = useState<string | null>(null);
  const [batchProgress, setBatchProgress] = useState<Record<string, BatchProgress>>({});
  const [batchProcessing, setBatchProcessing] = useState(false);
  const [overlayOpen, setOverlayOpen] = useState(false);
  const hydrationDone = useRef(false);

  const openOverlay = useCallback(() => setOverlayOpen(true), []);
  const closeOverlay = useCallback(() => setOverlayOpen(false), []);

  useEffect(() => {
    if (hydrationDone.current) return;
    hydrationDone.current = true;
    try {
      const stored = sessionStorage.getItem(BATCH_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as BatchItem[];
        if (
          Array.isArray(parsed) &&
          parsed.every((x): x is BatchItem => x && typeof x.inn === 'string' && typeof x.name === 'string')
        ) {
          setBatchItems(parsed);
        }
      }
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    try {
      if (batchItems.length > 0) {
        sessionStorage.setItem(BATCH_STORAGE_KEY, JSON.stringify(batchItems));
      } else {
        sessionStorage.removeItem(BATCH_STORAGE_KEY);
      }
    } catch {
      // ignore
    }
  }, [batchItems]);

  const [flyState, setFlyState] = useState<{ from: DOMRect } | null>(null);

  const triggerFlyToBatch = useCallback((sourceRect: DOMRect) => {
    setFlyState({ from: sourceRect });
    setTimeout(() => setFlyState(null), 900);
  }, []);

  const toggleBatch = useCallback((inn: string, name: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const btn = e.currentTarget as HTMLElement;
    const wasAdding = !batchItems.some(b => b.inn === inn);
    setBatchItems(prev => {
      const exists = prev.some(b => b.inn === inn);
      if (exists) return prev.filter(b => b.inn !== inn);
      return [...prev, { inn, name }];
    });
    if (wasAdding && btn) triggerFlyToBatch(btn.getBoundingClientRect());
  }, [batchItems, triggerFlyToBatch]);

  const toggleBatchPage = useCallback((items: { inn: string; name: string }[], e?: React.SyntheticEvent) => {
    const validItems = items.filter(x => x.inn);
    if (validItems.length === 0) return;
    const sourceEl = e?.currentTarget as HTMLElement | undefined;
    const willAdd = !validItems.every(x => batchItems.some(b => b.inn === x.inn));
    if (willAdd && sourceEl) triggerFlyToBatch(sourceEl.getBoundingClientRect());
    setBatchItems(prev => {
      const prevSet = new Set(prev.map(b => b.inn));
      const allOnPageInBatch = validItems.every(x => prevSet.has(x.inn));
      if (allOnPageInBatch) {
        return prev.filter(b => !validItems.some(x => x.inn === b.inn));
      }
      const toAdd = validItems.filter(x => !prevSet.has(x.inn));
      return [...prev, ...toAdd];
    });
  }, [batchItems, triggerFlyToBatch]);

  const removeFromBatch = useCallback((inn: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setBatchItems(prev => prev.filter(b => b.inn !== inn));
    setBatchProgress(prev => {
      const next = { ...prev };
      delete next[inn];
      return next;
    });
  }, []);

  const pollingInProgressRef = useRef(false);

  const pollBatchStatus = useCallback(async () => {
    if (batchItems.length === 0) return;
    if (pollingInProgressRef.current) return;
    pollingInProgressRef.current = true;
    try {
      const results = await Promise.all(
        batchItems.map(async ({ inn }) => {
          try {
            const res = await fetch(`/api/organizations/${inn}/contacts`, {
              headers: getAuthHeaders()
            });
            const json = (await res.json()) as {
              status?: string;
              stage?: string;
              data?: BatchProgress['data'];
              error?: string;
            };
            if (!res.ok) {
              return {
                inn,
                json: {
                  status: 'error' as const,
                  error: json.error ?? `HTTP ${res.status}`
                }
              };
            }
            return {
              inn,
              json: {
                status: (json.status ?? 'idle') as BatchProgress['status'],
                stage: json.stage,
                data: json.data,
                error: json.error
              }
            };
          } catch {
            return { inn, json: { status: 'error' as const, error: 'Сеть' } };
          }
        })
      );
      setBatchProgress(prev => {
        const next = { ...prev };
        results.forEach(({ inn, json }) => {
          next[inn] = {
            status: json.status as BatchProgress['status'],
            stage: json.stage,
            data: json.data,
            error: json.error
          };
        });
        return next;
      });
    } finally {
      pollingInProgressRef.current = false;
    }
  }, [batchItems]);

  const clearBatch = useCallback(() => {
    setBatchItems([]);
    setBatchProgress({});
    setBatchProcessing(false);
    setCurrentBatchId(null);
  }, []);

  const startBatch = useCallback(async () => {
    if (batchItems.length === 0) return;
    setBatchProcessing(true);
    setBatchProgress(prev => {
      const next = { ...prev };
      batchItems.forEach(b => {
        next[b.inn] = { status: 'running' };
      });
      return next;
    });

    try {
      const createRes = await fetch('/api/batches', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ inns: batchItems })
      });
      const createJson = (await createRes.json()) as { batchId?: string; error?: string };

      if (!createRes.ok) {
        alert(createJson.error || 'Ошибка создания батча');
        setBatchProcessing(false);
        return;
      }

      const batchId = createJson.batchId;
      if (batchId) setCurrentBatchId(batchId);

      const startRes = await fetch('/api/organizations/batch-contacts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ batchId })
      });
      const startJson = (await startRes.json()) as { error?: string };

      if (!startRes.ok) {
        alert(startJson.error || 'Ошибка запуска batch');
        setBatchProcessing(false);
        return;
      }

      // Триггер обновления истории (BatchesPage слушает currentBatchId), затем очистка
      queueMicrotask(() => clearBatch());
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Ошибка сети');
      setBatchProcessing(false);
      return;
    }
  }, [batchItems, clearBatch]);

  useEffect(() => {
    if (!batchProcessing || batchItems.length === 0) return;
    const interval = setInterval(pollBatchStatus, 3000);
    pollBatchStatus();
    return () => clearInterval(interval);
  }, [batchProcessing, batchItems, pollBatchStatus]);

  useEffect(() => {
    if (!batchProcessing || batchItems.length === 0) return;
    const allDone = batchItems.every(b => {
      const p = batchProgress[b.inn];
      return p && (p.status === 'completed' || p.status === 'error');
    });
    if (allDone) setBatchProcessing(false);
  }, [batchProcessing, batchItems, batchProgress]);

  const value: BatchContextValue = {
    batchItems,
    currentBatchId,
    batchProgress,
    batchProcessing,
    overlayOpen,
    toggleBatch,
    toggleBatchPage,
    removeFromBatch,
    startBatch,
    clearBatch,
    openOverlay,
    closeOverlay,
    setOverlayOpen
  };

  return (
    <BatchContext.Provider value={value}>
      {children}
      {flyState && typeof document !== 'undefined' && createPortal(
        <BatchFlyOverlay from={flyState.from} onComplete={() => setFlyState(null)} />,
        document.body
      )}
    </BatchContext.Provider>
  );
}

function BatchFlyOverlay({ from, onComplete }: { from: DOMRect; onComplete: () => void }) {
  const elRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = elRef.current;
    if (!el) return;
    const targets = document.querySelectorAll(`.${BATCH_NAV_BADGE_CLASS}`);
    const visible = Array.from(targets).find(t => {
      const r = t.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    });
    const targetRect = visible?.getBoundingClientRect();
    if (targetRect) {
      const toX = targetRect.left + targetRect.width / 2 - 12;
      const toY = targetRect.top + targetRect.height / 2 - 12;
      requestAnimationFrame(() => {
        el.style.transition = 'left 0.8s cubic-bezier(0.2, 0.8, 0.2, 1), top 0.8s cubic-bezier(0.2, 0.8, 0.2, 1), opacity 0.8s';
        el.style.left = `${toX}px`;
        el.style.top = `${toY}px`;
        el.style.opacity = '0';
      });
    }
    const t = setTimeout(onComplete, 900);
    return () => clearTimeout(t);
  }, [from, onComplete]);

  return (
    <div
      ref={elRef}
      className="fixed z-[9999] pointer-events-none"
      style={{
        left: from.left,
        top: from.top,
        width: 24,
        height: 24,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'rgb(31 41 55)',
        borderRadius: 12,
        boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
        transition: 'none'
      }}
    >
      <Plus className="w-4 h-4 text-white" strokeWidth={2.5} />
    </div>
  );
}
