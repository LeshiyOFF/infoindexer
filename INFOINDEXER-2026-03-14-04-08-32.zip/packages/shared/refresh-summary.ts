/**
 * Создаёт/обновляет таблицу financial_reports_summary для быстрых запросов
 * по revenue, age, net_profit и т.д. без полной агрегации financial_reports.
 * Вызывать после синка или по крону.
 */
import { ClickHouseClient } from '@clickhouse/client';

const CREATE_TABLE = `
  CREATE TABLE IF NOT EXISTS financial_reports_summary (
    inn String,
    ogrn String,
    region String,
    latest_year UInt16,
    records_count UInt64,
    lon String,
    lat String,
    has_geo UInt8,
    revenue Float64,
    net_profit Float64,
    charter_capital Float64,
    age Float32,
    has_director UInt8,
    has_name UInt8,
    name String,
    director String,
    status String,
    okved String,
    PROJECTION by_region (SELECT * ORDER BY (region, -revenue, inn)),
    PROJECTION by_age (SELECT * ORDER BY (age, -revenue, inn)),
    PROJECTION by_has_director (SELECT * ORDER BY (has_director, -revenue, inn)),
    PROJECTION by_has_name (SELECT * ORDER BY (has_name, -revenue, inn)),
    PROJECTION by_has_geo (SELECT * ORDER BY (has_geo, -revenue, inn)),
    PROJECTION by_records_count (SELECT * ORDER BY (records_count, -revenue, inn)),
    PROJECTION by_records_count_desc (SELECT * ORDER BY (-records_count, -revenue, inn)),
    PROJECTION by_status (SELECT * ORDER BY (status, -revenue, inn)),
    INDEX idx_name_ngram name TYPE ngrambf_v1(4, 256, 2, 0) GRANULARITY 4
  ) ENGINE = MergeTree()
  ORDER BY (-revenue, inn)
`;

const POPULATE = `
  INSERT INTO financial_reports_summary
  SELECT
    fr.inn,
    fr.ogrn,
    fr.region,
    fr.latest_year,
    fr.records_count,
    fr.lon,
    fr.lat,
    if((fr.lon != '' AND fr.lat != ''), 1, 0) as has_geo,
    fr.revenue,
    fr.net_profit,
    fr.charter_capital,
    fr.age,
    if(cm.director != '', 1, 0) as has_director,
    if(cm.name != '', 1, 0) as has_name,
    coalesce(cm.name, '') as name,
    coalesce(cm.director, '') as director,
    coalesce(cm.status, '') as status,
    coalesce(fr.okved, '') as okved
  FROM (
    SELECT
      inn,
      toString(argMax(ogrn, year)) as ogrn,
      toString(argMax(region, year)) as region,
      toUInt16(max(year)) as latest_year,
      toUInt64(count()) as records_count,
      toString(argMax(lon, year)) as lon,
      toString(argMax(lat, year)) as lat,
      toFloat64OrZero(toString(argMax(PL_revenue, year))) as revenue,
      toFloat64OrZero(toString(argMax(PL_net_profit, year))) as net_profit,
      toFloat64OrZero(toString(argMax(B_charter_capital, year))) as charter_capital,
      toFloat32OrZero(toString(argMax(age, year))) as age,
      toString(argMax(okved, year)) as okved
    FROM financial_reports
    GROUP BY inn
  ) fr
  LEFT JOIN (
    SELECT inn, argMax(director, updated_at) as director, argMax(name, updated_at) as name, argMax(status, updated_at) as status
    FROM companies_meta
    GROUP BY inn
  ) cm ON fr.inn = cm.inn
`;

export type RefreshProgressReporter = (
  stage: string,
  percentage: number,
  message: string
) => Promise<void> | void;

export async function refreshFinancialSummary(
  client: ClickHouseClient,
  options?: { reportProgress?: RefreshProgressReporter }
): Promise<{ rows: number; elapsedMs: number }> {
  const start = Date.now();
  const report = options?.reportProgress;

  await report?.('drop', 0, 'Удаление старой таблицы');
  await client.command({ query: 'DROP TABLE IF EXISTS financial_reports_summary' });

  await report?.('create', 5, 'Создание схемы');
  await client.command({ query: CREATE_TABLE });

  await report?.('insert', 10, 'Загрузка данных...');
  await client.command({ query: POPULATE });
  await report?.('insert_done', 80, 'Данные загружены');

  await report?.('optimize', 85, 'Оптимизация таблицы');
  await client.command({ query: 'OPTIMIZE TABLE financial_reports_summary FINAL' });

  await report?.('count', 95, 'Подсчёт строк');
  const res = await client.query({ query: 'SELECT count() as c FROM financial_reports_summary', format: 'JSONEachRow' });
  const data = await res.json() as { c: string }[];
  const rows = parseInt(data[0]?.c || '0');

  await report?.('done', 100, 'Готово');
  return { rows, elapsedMs: Date.now() - start };
}
