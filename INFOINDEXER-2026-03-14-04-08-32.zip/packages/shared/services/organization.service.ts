import { ClickHouseClient } from '@clickhouse/client';
import { CompanyMeta, FinancialReport, ApiResponse } from '../interfaces';

const CACHE_NOT_READY_ERROR = 'Кэш не готов. Обновите кэш в настройках.';

export class OrganizationService {
  constructor(private client: ClickHouseClient) {}

  async search(params: {
    search?: string;
    page?: number;
    limit?: number;
    sortBy?: string;
    sortOrder?: string;
    region?: string;
    hasGeo?: string;
    minRevenue?: number;
    maxRevenue?: number;
    minAge?: number;
    maxAge?: number;
    minCharterCapital?: number;
    status?: string;
    hasDirector?: boolean;
    hasName?: boolean;
    okved?: string;
  }): Promise<ApiResponse<CompanyMeta[]>> {
    const {
      search = '',
      page = 1,
      limit = 50,
      sortBy = 'records_count',
      sortOrder = 'DESC',
      region = '',
      hasGeo = '',
      minRevenue,
      maxRevenue,
      minAge,
      maxAge,
      minCharterCapital,
      status,
      hasDirector,
      hasName,
      okved
    } = params;

    const offset = (page - 1) * limit;

    // Проверка существования и непустоты summary
    let summaryReady = false;
    let hasOkvedColumn = false;
    try {
      const [probeRes, colRes] = await Promise.all([
        this.client.query({ query: 'SELECT 1 FROM financial_reports_summary LIMIT 1', format: 'JSONEachRow' }),
        this.client.query({
          query: "SELECT 1 FROM system.columns WHERE database = currentDatabase() AND table = 'financial_reports_summary' AND name = 'okved' LIMIT 1",
          format: 'JSONEachRow'
        })
      ]);
      const probeRows = (await probeRes.json()) as unknown[];
      summaryReady = Array.isArray(probeRows) && probeRows.length > 0;
      const colRows = (await colRes.json()) as unknown[];
      hasOkvedColumn = Array.isArray(colRows) && colRows.length > 0;
    } catch {
      /* таблица не создана */
    }
    if (!summaryReady) {
      return {
        data: [],
        pagination: { total: 0, page, limit, totalPages: 0 },
        error: CACHE_NOT_READY_ERROR
      };
    }

    type QueryParamValue = string | number | string[] | undefined;
    const queryParams: Record<string, QueryParamValue> = {
      limit,
      offset,
      search: search ? (search.match(/^\d+$/) ? search : `%${search}%`) : ''
    };

    const isNumericSearch = /^\d+$/.test(search);
    const summaryWhere: string[] = ['1=1'];

    if (region) {
      summaryWhere.push('region = {region: String}');
      queryParams.region = region;
    }
    // Только при явном true применяем фильтр; снятая галочка = без фильтра
    if (hasGeo === 'true') summaryWhere.push('has_geo = 1');
    if (minRevenue !== undefined) {
      summaryWhere.push('revenue >= {minRevenue: Int64}');
      queryParams.minRevenue = minRevenue;
    }
    if (maxRevenue !== undefined) {
      summaryWhere.push('revenue <= {maxRevenue: Int64}');
      queryParams.maxRevenue = maxRevenue;
    }
    if (minAge !== undefined) {
      summaryWhere.push('age >= {minAge: Int32}');
      queryParams.minAge = minAge;
    }
    if (maxAge !== undefined) {
      summaryWhere.push('age <= {maxAge: Int32}');
      queryParams.maxAge = maxAge;
    }
    if (minCharterCapital !== undefined) {
      summaryWhere.push('charter_capital >= {minCharterCapital: Int64}');
      queryParams.minCharterCapital = minCharterCapital;
    }
    // Только при явном true применяем фильтр; снятая галочка = без фильтра
    if (hasDirector === true) summaryWhere.push('has_director = 1');
    if (hasName === true) summaryWhere.push('has_name = 1');
    if (status) {
      summaryWhere.push('status = {status: String}');
      queryParams.status = status;
    }
    // Фильтр по ОКВЭД: только если колонка okved есть в таблице
    if (hasOkvedColumn && okved && okved.trim()) {
      summaryWhere.push('startsWith(okved, {okvedPrefix: String})');
      queryParams.okvedPrefix = okved.trim();
    }

    if (search) {
      if (isNumericSearch) {
        summaryWhere.push(
          "(inn = {search: String} OR inn LIKE concat({search: String}, '%') OR ogrn = {search: String})"
        );
      } else {
        summaryWhere.push('name ILIKE {search: String}');
      }
    }

    const allowedSortFields = ['inn', 'ogrn', 'latest_year', 'records_count', 'name', 'revenue', 'age', 'net_profit', 'director'];
    const safeSortBy = allowedSortFields.includes(sortBy) ? sortBy : 'records_count';
    const safeSortOrder = sortOrder.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

    const financialSortFields = ['latest_year', 'records_count', 'revenue', 'age', 'net_profit', 'ogrn'];
    const isFinancialSort = financialSortFields.includes(safeSortBy);
    const sortColSummary = isFinancialSort
      ? safeSortBy === 'revenue'
        ? 'revenue'
        : safeSortBy
      : safeSortBy === 'name'
        ? 'name'
        : safeSortBy === 'director'
          ? 'director'
          : 'inn';

    const countQuery = `
      SELECT count() as total
      FROM financial_reports_summary
      WHERE ${summaryWhere.join(' AND ')}
    `;

    const selectCols = hasOkvedColumn
      ? 'inn, name, ogrn, region, latest_year, records_count, lon, lat, status, director, revenue, net_profit, charter_capital, age, okved'
      : 'inn, name, ogrn, region, latest_year, records_count, lon, lat, status, director, revenue, net_profit, charter_capital, age';
    const mainQuery = `
      SELECT ${selectCols}
      FROM financial_reports_summary
      WHERE ${summaryWhere.join(' AND ')}
      ORDER BY ${sortColSummary} ${safeSortOrder}
      LIMIT {limit: Int32} OFFSET {offset: Int32}
    `;

    const querySettings = {
      max_memory_usage: '10000000000',
      join_algorithm: 'auto' as const,
      max_bytes_before_external_group_by: '4000000000',
      max_bytes_before_external_sort: '4000000000'
    };

    const queryStart = Date.now();
    const [countResult, result] = await Promise.all([
      this.client.query({
        query: countQuery,
        query_params: queryParams,
        format: 'JSONEachRow',
        clickhouse_settings: querySettings
      }),
      this.client.query({
        query: mainQuery,
        query_params: queryParams,
        format: 'JSONEachRow',
        clickhouse_settings: querySettings
      })
    ]);
    const clickhouseMs = Date.now() - queryStart;
    if (process.env.NODE_ENV !== 'production' && clickhouseMs > 1000) {
      console.warn(
        `[OrganizationService] ClickHouse slow: ${clickhouseMs}ms | sortBy=${safeSortBy}`
      );
    }

    const data = (await result.json()) as CompanyMeta[];
    const countData = (await countResult.json()) as { total: string }[];
    const total = parseInt(countData[0]?.total || '0');

    return {
      data,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      }
    };
  }

  async getById(id: string): Promise<{ data: FinancialReport[]; meta: CompanyMeta | null; connections: Partial<CompanyMeta>[] }> {
    const financialQuery = `
      SELECT *
      FROM financial_reports
      WHERE inn = {id: String} OR (inn = '' AND ogrn = {id: String})
      ORDER BY year DESC
    `;

    const metaQuery = `
      SELECT *
      FROM companies_meta
      WHERE inn = {id: String}
      LIMIT 1
    `;

    const [fRes, mRes] = await Promise.all([
      this.client.query({ query: financialQuery, query_params: { id }, format: 'JSONEachRow' }),
      this.client.query({ query: metaQuery, query_params: { id }, format: 'JSONEachRow' })
    ]);

    const data = (await fRes.json()) as FinancialReport[];
    const metaRecords = (await mRes.json()) as CompanyMeta[];
    const meta = metaRecords.length > 0 ? metaRecords[0] : null;

    let connections: Partial<CompanyMeta>[] = [];
    if (meta) {
      const { director, founders = [], inn } = meta;
      let connectionQuery = `
        SELECT inn, name, director, status
        FROM companies_meta
        WHERE ((director != '' AND director = {director: String})`;

      const connParams: Record<string, string | string[]> = { director, id: inn };

      if (founders.length > 0) {
        connectionQuery += ` OR hasAny(founders, {founders: Array(String)})`;
        connParams.founders = founders;
      }
      connectionQuery += `) AND inn != {id: String} LIMIT 10`;

      try {
        const cRes = await this.client.query({
          query: connectionQuery,
          query_params: connParams,
          format: 'JSONEachRow'
        });
        connections = (await cRes.json()) as Partial<CompanyMeta>[];
      } catch (e) {
        console.error('Service Connections Error:', e);
      }
    }

    return { data, meta, connections };
  }
}
