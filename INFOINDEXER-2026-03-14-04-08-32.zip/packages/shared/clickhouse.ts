import { createClient } from '@clickhouse/client';

export const clickhouseClient = createClient({
  url: process.env.CLICKHOUSE_HOST ? `http://${process.env.CLICKHOUSE_HOST}:8123` : 'http://localhost:8123',
  username: process.env.CLICKHOUSE_USER || 'default',
  password: process.env.CLICKHOUSE_PASSWORD || undefined,
  database: process.env.CLICKHOUSE_DB || 'default',
  request_timeout: 100000,
});
